
package Sub::Util;

use strict;
use warnings;

require Exporter;
require List::Util; # as it has the XS

our @ISA = qw( Exporter );
our @EXPORT_OK = qw(
  prototype set_prototype
  subname set_subname
);

our $VERSION    = "1.41";
$VERSION   = eval $VERSION;




sub prototype
{
  my ( $code ) = @_;
  return CORE::prototype( $code );
}





1;
