



$utf8::SwashInfo{'ToIsc'}{'format'} = 'd'; # single decimal digit
$utf8::SwashInfo{'ToIsc'}{'missing'} = ''; # code point maps to the null string

return <<'END';
END
