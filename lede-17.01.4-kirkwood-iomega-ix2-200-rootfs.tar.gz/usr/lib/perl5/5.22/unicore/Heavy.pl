




%utf8::loose_property_name_of = (
'age' => 'age',
'ahex' => 'ahex',
'alpha' => 'alpha',
'alphabetic' => 'alpha',
'asciihexdigit' => 'ahex',
'bc' => 'bc',
'bidic' => 'bidic',
'bidiclass' => 'bc',
'bidicontrol' => 'bidic',
'bidim' => 'bidim',
'bidimirrored' => 'bidim',
'bidipairedbrackettype' => 'bpt',
'blk' => 'blk',
'block' => 'blk',
'bpt' => 'bpt',
'canonicalcombiningclass' => 'ccc',
'cased' => 'cased',
'caseignorable' => 'ci',
'category' => 'gc',
'ccc' => 'ccc',
'ce' => 'ce',
'changeswhencasefolded' => 'cwcf',
'changeswhencasemapped' => 'cwcm',
'changeswhenlowercased' => 'cwl',
'changeswhennfkccasefolded' => 'cwkcf',
'changeswhentitlecased' => 'cwt',
'changeswhenuppercased' => 'cwu',
'ci' => 'ci',
'compex' => 'compex',
'compositionexclusion' => 'ce',
'cwcf' => 'cwcf',
'cwcm' => 'cwcm',
'cwkcf' => 'cwkcf',
'cwl' => 'cwl',
'cwt' => 'cwt',
'cwu' => 'cwu',
'dash' => 'dash',
'decompositiontype' => 'dt',
'defaultignorablecodepoint' => 'di',
'dep' => 'dep',
'deprecated' => 'dep',
'di' => 'di',
'dia' => 'dia',
'diacritic' => 'dia',
'dt' => 'dt',
'ea' => 'ea',
'eastasianwidth' => 'ea',
'ext' => 'ext',
'extender' => 'ext',
'fullcompositionexclusion' => 'compex',
'gc' => 'gc',
'gcb' => 'gcb',
'generalcategory' => 'gc',
'graphemebase' => 'grbase',
'graphemeclusterbreak' => 'gcb',
'graphemeextend' => 'grext',
'grbase' => 'grbase',
'grext' => 'grext',
'hangulsyllabletype' => 'hst',
'hex' => 'hex',
'hexdigit' => 'hex',
'hst' => 'hst',
'hyphen' => 'hyphen',
'idc' => 'idc',
'idcontinue' => 'idc',
'ideo' => 'ideo',
'ideographic' => 'ideo',
'ids' => 'ids',
'idsb' => 'idsb',
'idsbinaryoperator' => 'idsb',
'idst' => 'idst',
'idstart' => 'ids',
'idstrinaryoperator' => 'idst',
'in' => 'in',
'jg' => 'jg',
'joinc' => 'joinc',
'joincontrol' => 'joinc',
'joininggroup' => 'jg',
'joiningtype' => 'jt',
'jt' => 'jt',
'lb' => 'lb',
'linebreak' => 'lb',
'loe' => 'loe',
'logicalorderexception' => 'loe',
'lower' => 'lower',
'lowercase' => 'lower',
'math' => 'math',
'nchar' => 'nchar',
'nfcqc' => 'nfcqc',
'nfcquickcheck' => 'nfcqc',
'nfdqc' => 'nfdqc',
'nfdquickcheck' => 'nfdqc',
'nfkcqc' => 'nfkcqc',
'nfkcquickcheck' => 'nfkcqc',
'nfkdqc' => 'nfkdqc',
'nfkdquickcheck' => 'nfkdqc',
'noncharactercodepoint' => 'nchar',
'nt' => 'nt',
'numerictype' => 'nt',
'numericvalue' => 'nv',
'nv' => 'nv',
'patsyn' => 'patsyn',
'patternsyntax' => 'patsyn',
'patternwhitespace' => 'patws',
'patws' => 'patws',
'presentin' => 'in',
'qmark' => 'qmark',
'quotationmark' => 'qmark',
'radical' => 'radical',
'sb' => 'sb',
'sc' => 'sc',
'script' => 'sc',
'scriptextensions' => 'scx',
'scx' => 'scx',
'sd' => 'sd',
'sentencebreak' => 'sb',
'softdotted' => 'sd',
'space' => 'wspace',
'sterm' => 'sterm',
'term' => 'term',
'terminalpunctuation' => 'term',
'uideo' => 'uideo',
'unifiedideograph' => 'uideo',
'upper' => 'upper',
'uppercase' => 'upper',
'variationselector' => 'vs',
'vs' => 'vs',
'wb' => 'wb',
'whitespace' => 'wspace',
'wordbreak' => 'wb',
'wspace' => 'wspace',
'xidc' => 'xidc',
'xidcontinue' => 'xidc',
'xids' => 'xids',
'xidstart' => 'xids',
);

@utf8::inline_definitions = (

'V0',
'V1
0',
'V2
0
1114112',
'V4
9
14
32
33',
'V6
10
14
133
134
8232
8234',
'V6
48
58
65
91
97
123',
'V4
65
91
97
123',
'V4
9
10
32
33',
'V4
0
32
127
128',
'V2
48
58',
'V2
33
127',
'V2
97
123',
'V2
32
127',
'V2
65
91',
'V2
12334
12336',
'V2
119149
119150',
'V6
1454
1455
6313
6314
12331
12332',
'V2
12330
12331',
'V6
861
863
864
866
7629
7630',
'V2
837
838',
'V2
12441
12443',
'V2
7630
7631',
'V6
801
803
807
809
7632
7633',
'V2
1456
1457',
'V2
1457
1458',
'V2
1458
1459',
'V2
1459
1460',
'V2
1460
1461',
'V2
1461
1462',
'V2
1462
1463',
'V2
1463
1464',
'V4
1464
1465
1479
1480',
'V2
1465
1467',
'V2
1467
1468',
'V2
1468
1469',
'V2
1469
1470',
'V2
1471
1472',
'V2
1473
1474',
'V2
1474
1475',
'V2
64286
64287',
'V4
1611
1612
2288
2289',
'V4
1612
1613
2289
2290',
'V4
1613
1614
2290
2291',
'V4
1560
1561
1614
1615',
'V4
1561
1562
1615
1616',
'V4
1562
1563
1616
1617',
'V2
1617
1618',
'V2
1618
1619',
'V2
1648
1649',
'V2
1809
1810',
'V2
3157
3158',
'V2
3158
3159',
'V2
3640
3642',
'V2
3656
3660',
'V2
3768
3770',
'V2
3784
3788',
'V2
3953
3954',
'V6
3954
3955
3962
3966
3968
3969',
'V2
3956
3957',
'V6
48
58
65
71
97
103',
'V4
4352
4448
43360
43389',
'V4
4520
4608
55243
55292',
'V4
4448
4520
55216
55239',
'V2
13
14',
'V2
10
11',
'V2
127462
127488',
'V4
12272
12274
12276
12284',
'V2
12274
12276',
'V2
8204
8206',
'V6
11904
11930
11931
12020
12032
12246',
'V4
133
134
8232
8234',
'V6
6155
6158
65024
65040
917760
918000',
'V2
34
35',
'V6
11
13
133
134
8232
8234',
'V2
39
40',
'V4
8364
8365
65532
65533',
'V2
8378
8379',
'V4
1564
1565
8294
8298',
'V6
9
10
11
12
31
32',
'V2
8296
8297',
'V2
8234
8235',
'V2
8294
8295',
'V2
8237
8238',
'V2
8236
8237',
'V2
8297
8298',
'V2
8235
8236',
'V2
8295
8296',
'V2
8238
8239',
'V2
65024
65040',
'V2
19968
40960',
'V2
12272
12288',
'V2
3712
3840',
'V2
92736
92784',
'V2
1984
2048',
'V2
9280
9312',
'V2
57344
63744',
'V2
42240
42560',
'V2
43520
43616',
'V2
4352
4608',
'V2
42192
42240',
'V2
93952
94112',
'V2
71168
71264',
'V2
69216
69248',
'V2
917504
917632',
'V2
3584
3712',
'V2
5120
5760',
'V2
0
128',
'V2
42656
42752',
'V2
7104
7168',
'V2
5952
5984',
'V2
880
1024',
'V2
6016
6144',
'V2
6400
6480',
'V2
119040
119296',
'V2
5760
5792',
'V2
2816
2944',
'V2
5792
5888',
'V2
6480
6528',
'V2
71296
71376',
'V2
2944
3072',
'V2
917760
918000',
'V2
1536
1792',
'V2
8592
8704',
'V2
69632
69760',
'V2
66208
66272',
'V2
69888
69968',
'V2
11392
11520',
'V2
127024
127136',
'V2
66352
66384',
'V2
44032
55216',
'V2
1424
1536',
'V2
592
688',
'V2
69760
69840',
'V2
12688
12704',
'V2
12032
12256',
'V2
70144
70224',
'V2
128
256',
'V2
7168
7248',
'V2
66176
66208',
'V2
67872
67904',
'V2
43312
43360',
'V2
1792
1872',
'V2
3072
3200',
'V2
1920
1984',
'V2
19904
19968',
'V2
68352
68416',
'V2
2432
2560',
'V2
10240
10496',
'V2
13312
19904',
'V2
131072
173792',
'V2
173824
177984',
'V2
177984
178208',
'V2
66560
66640',
'V2
66816
66864',
'V2
70400
70528',
'V2
5920
5952',
'V2
110592
110848',
'V2
3200
3328',
'V2
43264
43312',
'V2
67072
67456',
'V2
126976
127024',
'V2
2112
2144',
'V2
4096
4256',
'V2
7248
7296',
'V2
66688
66736',
'V2
43072
43136',
'V2
70016
70112',
'V2
66640
66688',
'V2
71040
71168',
'V2
3456
3584',
'V2
983040
1048576',
'V2
1048576
1114112',
'V2
5888
5920',
'V2
6688
6832',
'V2
43648
43744',
'V2
3840
4096',
'V2
70784
70880',
'V2
6320
6400',
'V2
1328
1424',
'V2
6912
7040',
'V2
92160
92736',
'V2
92880
92928',
'V2
12544
12592',
'V2
6656
6688',
'V2
5024
5120',
'V2
1024
1280',
'V2
9984
10176',
'V2
113664
113824',
'V2
4608
4992',
'V2
4256
4352',
'V2
7936
8192',
'V2
2688
2816',
'V2
2560
2688',
'V2
12352
12448',
'V2
43360
43392',
'V2
55216
55296',
'V2
43392
43488',
'V2
12448
12544',
'V2
69968
70016',
'V2
66000
66048',
'V2
65520
65536',
'V2
5984
6016',
'V2
11568
11648',
'V2
66432
66464',
'V2
7376
7424',
'V2
64336
65024',
'V2
65136
65280',
'V2
1872
1920',
'V2
13056
13312',
'V2
73728
74752',
'V2
128512
128592',
'V2
65056
65072',
'V2
70320
70400',
'V2
256
384',
'V2
384
592',
'V2
11360
11392',
'V2
42784
43008',
'V2
43824
43888',
'V2
3328
3456',
'V2
6144
6320',
'V2
67712
67760',
'V2
6528
6624',
'V2
66304
66352',
'V2
66384
66432',
'V2
68608
68688',
'V2
67680
67712',
'V2
72384
72448',
'V2
2048
2112',
'V2
7040
7104',
'V2
128768
128896',
'V2
2208
2304',
'V2
126464
126720',
'V2
9472
9600',
'V2
12736
12784',
'V2
12288
12352',
'V2
12592
12688',
'V2
2304
2432',
'V2
11264
11360',
'V2
68096
68192',
'V2
68288
68352',
'V2
11008
11264',
'V2
66464
66528',
'V2
67840
67872',
'V2
43136
43232',
'V2
65104
65136',
'V2
10224
10240',
'V2
10496
10624',
'V2
129024
129280',
'V2
71840
71936',
'V2
42128
42192',
'V2
12704
12736',
'V2
119648
119680',
'V2
1280
1328',
'V2
12800
13056',
'V2
11648
11744',
'V2
4992
5024',
'V2
11520
11568',
'V2
12784
12800',
'V2
43968
44032',
'V2
9728
9984',
'V2
43616
43648',
'V2
43488
43520',
'V2
8528
8592',
'V2
92928
93072',
'V2
7424
7552',
'V2
8192
8304',
'V2
69840
69888',
'V2
8304
8352',
'V2
43008
43056',
'V2
119552
119648',
'V2
40960
42128',
'V2
64256
64336',
'V2
11744
11776',
'V2
42560
42656',
'V2
768
880',
'V2
43776
43824',
'V2
6624
6656',
'V2
119808
120832',
'V2
124928
125152',
'V2
127136
127232',
'V2
7360
7376',
'V2
65792
65856',
'V2
9600
9632',
'V2
43232
43264',
'V2
56320
57344',
'V2
8704
8960',
'V2
8960
9216',
'V2
65040
65056',
'V2
65936
66000',
'V2
118784
119040',
'V2
65072
65104',
'V2
11904
12032',
'V2
55296
56192',
'V2
43744
43776',
'V2
7552
7616',
'V2
68480
68528',
'V2
11776
11904',
'V2
9216
9280',
'V2
8352
8400',
'V2
6832
6912',
'V2
7616
7680',
'V2
9632
9728',
'V2
67648
67680',
'V2
68000
68096',
'V2
127744
128512',
'V2
688
768',
'V2
68224
68256',
'V2
68192
68224',
'V2
128640
128768',
'V2
74752
74880',
'V2
67584
67648',
'V2
9312
9472',
'V2
65280
65520',
'V2
56192
56320',
'V2
43056
43072',
'V2
65664
65792',
'V2
65536
65664',
'V2
10176
10224',
'V2
10624
10752',
'V2
10752
11008',
'V2
119296
119376',
'V2
66864
66928',
'V2
8448
8528',
'V2
66272
66304',
'V2
128896
129024',
'V2
7680
7936',
'V2
128592
128640',
'V2
65856
65936',
'V2
63744
64256',
'V2
77824
78896',
'V2
127232
127488',
'V2
67968
68000',
'V2
42752
42784',
'V2
68448
68480',
'V2
68416
68448',
'V2
70112
70144',
'V2
194560
195104',
'V2
8400
8448',
'V2
127488
127744',
'V2
113824
113840',
'V6
188
191
8528
8544
8585
8586',
'V6
65104
65107
65108
65127
65128
65132',
'V6
12288
12289
65281
65377
65504
65511',
'V4
0
32
127
160',
'V6
57344
63744
983040
1048574
1048576
1114110',
'V2
55296
57344',
'V2
8232
8233',
'V2
8233
8234',
'V2
1829
1830',
'V2
1871
1872',
'V2
1815
1816',
'V2
1830
1831',
'V2
1607
1608',
'V6
1603
1604
1708
1711
1919
1920',
'V2
1825
1826',
'V2
1826
1827',
'V2
1725
1726',
'V6
1591
1593
1695
1696
2211
2212',
'V2
1836
1837',
'V4
1810
1811
1837
1838',
'V2
1818
1819',
'V2
1823
1824',
'V6
1605
1606
1893
1895
2215
2216',
'V6
1606
1607
1721
1725
1895
1898',
'V2
1833
1834',
'V2
1835
1836',
'V2
1819
1821',
'V2
1821
1822',
'V2
1817
1818',
'V2
1808
1809',
'V4
1811
1813
1838
1839',
'V2
1870
1871',
'V2
1832
1833',
'V2
1869
1870',
'V2
1824
1825',
'V2
1822
1823',
'V2
1729
1731',
'V2
1827
1828',
'V2
1706
1707',
'V2
1816
1817',
'V2
1746
1748',
'V6
1813
1815
1834
1835
1839
1840',
'V4
1726
1727
1791
1792',
'V2
1831
1832',
'V6
1577
1578
1728
1729
1749
1750',
'V2
2220
2221',
'V2
2225
2226',
'V2
1741
1742',
'V2
1828
1829',
'V2
68315
68317',
'V2
68310
68311',
'V2
68311
68312',
'V2
68331
68332',
'V2
68324
68325',
'V2
68333
68334',
'V2
68295
68296',
'V2
1731
1732',
'V2
68313
68315',
'V2
68289
68291',
'V2
68332
68333',
'V2
68301
68302',
'V2
68304
68307',
'V2
68318
68321',
'V2
68321
68322',
'V2
68302
68303',
'V2
68303
68304',
'V2
68288
68289',
'V2
68291
68293',
'V2
68317
68318',
'V2
68297
68299',
'V2
68293
68294',
'V2
68307
68308',
'V2
68312
68313',
'V2
68334
68335',
'V2
68308
68309',
'V2
68335
68336',
'V2
68309
68310',
'V2
1914
1916',
'V6
43122
43123
68301
68302
68311
68312',
'V4
8212
8213
11834
11836',
'V4
11
13
8232
8234',
'V2
65532
65533',
'V4
41
42
93
94',
'V2
45
46',
'V6
8228
8231
65049
65050
68342
68343',
'V2
133
134',
'V2
55296
57344',
'V2
32
33',
'V2
47
48',
'V4
8288
8289
65279
65280',
'V2
8203
8204',
'V2
12881
12882',
'V2
12882
12883',
'V2
12883
12884',
'V2
12884
12885',
'V2
12885
12886',
'V2
12886
12887',
'V2
12887
12888',
'V2
12888
12889',
'V2
12889
12890',
'V2
12891
12892',
'V2
12892
12893',
'V2
12893
12894',
'V2
12894
12895',
'V2
12895
12896',
'V2
12977
12978',
'V2
12978
12979',
'V2
12979
12980',
'V2
12980
12981',
'V2
12982
12983',
'V2
12983
12984',
'V2
12984
12985',
'V2
12985
12986',
'V2
12986
12987',
'V2
12987
12988',
'V2
12988
12989',
'V2
12989
12990',
'V2
12990
12991',
'V2
8533
8534',
'V4
8537
8538
74849
74850',
'V2
8528
8529',
'V2
8529
8530',
'V2
8534
8535',
'V6
65818
65819
66292
66293
69235
69236',
'V2
3883
3884',
'V2
8535
8536',
'V2
8540
8541',
'V2
8536
8537',
'V6
65820
65821
66294
66295
69237
69238',
'V2
3884
3885',
'V4
8538
8539
74844
74845',
'V2
8541
8542',
'V6
65822
65823
66296
66297
69239
69240',
'V2
3885
3886',
'V2
8542
8543',
'V6
65823
65824
66297
66298
69240
69241',
'V6
65824
65825
66298
66299
69241
69242',
'V2
3886
3887',
'V2
3891
3892',
'V2
8530
8531',
'V6
2548
2549
2933
2934
43059
43060',
'V2
3887
3888',
'V2
3888
3889',
'V2
3889
3890',
'V2
3890
3891',
'V2
65827
65828',
'V6
2550
2551
2935
2936
43061
43062',
'V2
65828
65829',
'V2
65829
65830',
'V2
65831
65832',
'V2
65832
65833',
'V2
65833
65834',
'V2
65834
65835',
'V2
65836
65837',
'V2
65837
65838',
'V2
65838
65839',
'V2
65840
65841',
'V2
65841
65842',
'V2
65842
65843',
'V2
65843
65844',
'V2
8584
8585',
'V2
74802
74803',
'V2
74803
74804',
'V2
93022
93023',
'V6
20159
20160
20740
20741
93023
93024',
'V2
93024
93025',
'V4
20806
20807
93025
93026',
'V4
40960
42125
42128
42183',
'V6
92736
92767
92768
92778
92782
92784',
'V2
1984
2043',
'V2
42240
42540',
'V4
66864
66916
66927
66928',
'V4
67648
67670
67671
67680',
'V4
68352
68406
68409
68416',
'V4
6912
6988
6992
7037',
'V4
42656
42744
92160
92729',
'V4
92880
92910
92912
92918',
'V4
7104
7156
7164
7168',
'V6
746
748
12549
12590
12704
12731',
'V6
69632
69710
69714
69744
69759
69760',
'V4
6656
6684
6686
6688',
'V2
5952
5972',
'V4
69888
69941
69942
69956',
'V4
5120
5760
6320
6390',
'V2
66208
66257',
'V2
5024
5109',
'V6
994
1008
11392
11508
11513
11520',
'V2
77824
78895',
'V2
66816
66856',
'V4
11264
11311
11312
11359',
'V2
66352
66379',
'V2
5920
5941',
'V2
66304
66340',
'V6
43392
43470
43472
43482
43486
43488',
'V4
43264
43310
43311
43312',
'V4
70144
70162
70163
70206',
'V2
69760
69826',
'V6
7168
7224
7227
7242
7245
7248',
'V6
67072
67383
67392
67414
67424
67432',
'V2
66176
66205',
'V4
67872
67898
67903
67904',
'V2
69968
70007',
'V4
2112
2140
2142
2143',
'V4
68288
68327
68331
68343',
'V4
124928
125125
125127
125143',
'V4
68000
68024
68030
68032',
'V6
93952
94021
94032
94079
94095
94112',
'V4
71168
71237
71248
71258',
'V6
43744
43767
43968
44014
44016
44026',
'V6
4096
4256
43488
43519
43616
43648',
'V4
67712
67743
67751
67760',
'V2
5760
5789',
'V2
68608
68681',
'V4
66688
66718
66720
66730',
'V2
72384
72441',
'V2
66384
66427',
'V2
43072
43128',
'V4
68448
68467
68472
68480',
'V6
68480
68498
68505
68509
68521
68528',
'V4
67840
67868
67871
67872',
'V4
68416
68438
68440
68448',
'V4
43312
43348
43359
43360',
'V4
5792
5867
5870
5881',
'V4
2048
2094
2096
2111',
'V4
43136
43205
43214
43226',
'V6
70016
70089
70093
70094
70096
70107',
'V4
71040
71094
71096
71114',
'V4
70320
70379
70384
70394',
'V4
69840
69865
69872
69882',
'V4
7040
7104
7360
7368',
'V2
43008
43052',
'V6
1792
1806
1807
1867
1869
1872',
'V6
5984
5997
5998
6001
6002
6004',
'V4
71296
71352
71360
71370',
'V4
6480
6510
6512
6517',
'V4
43648
43715
43739
43744',
'V6
11568
11624
11631
11633
11647
11648',
'V4
5888
5901
5902
5909',
'V2
1920
1970',
'V4
3585
3643
3648
3676',
'V4
70784
70856
70864
70874',
'V4
66432
66462
66463
66464',
'V4
71840
71923
71935
71936',
'V4
66464
66500
66504
66518',
'V6
73728
74649
74752
74863
74864
74869',
'V6
6656
6684
6686
6688
43471
43472',
'V4
5941
5943
5952
5972',
'V2
5920
5943',
'V6
43392
43470
43471
43482
43486
43488',
'V6
2790
2800
70144
70162
70163
70206',
'V6
2406
2416
43056
43066
69760
69826',
'V6
2404
2416
43056
43066
69968
70007',
'V6
1600
1601
2112
2140
2142
2143',
'V6
1600
1601
68288
68327
68331
68343',
'V6
43056
43066
71168
71237
71248
71258',
'V6
6146
6148
6149
6150
43072
43128',
'V6
2404
2406
2534
2544
43008
43052',
'V6
4160
4170
6480
6510
6512
6517',
'V6
5888
5901
5902
5909
5941
5943',
,
);

%utf8::stricter_to_file_of = (
'_canondcij' => 'SD/Y',
'_case_ignorable' => 'CI/Y',
'_combabove' => 'Ccc/A',
'_perl_any_folds' => 'Perl/_PerlAny',
'_perl_charname_begin' => 'Perl/_PerlCha',
'_perl_charname_continue' => 'Perl/_PerlCh2',
'_perl_folds_to_multi_char' => 'Perl/_PerlFol',
'_perl_idcont' => 'Perl/_PerlIDC',
'_perl_idstart' => 'Perl/_PerlIDS',
'_perl_problematic_locale_foldeds_start' => 'Perl/_PerlPr2',
'_perl_problematic_locale_folds' => 'Perl/_PerlPro',
'_perl_quotemeta' => 'Perl/_PerlQuo',
'age=1.1' => 'Age/V11',
'age=2' => 'Age/V20',
'age=2.0' => 'Age/V20',
'age=2.1' => '#/75',
'age=3' => 'Age/V30',
'age=3.0' => 'Age/V30',
'age=3.1' => 'Age/V31',
'age=3.2' => 'Age/V32',
'age=4' => 'Age/V40',
'age=4.0' => 'Age/V40',
'age=4.1' => 'Age/V41',
'age=5' => 'Age/V50',
'age=5.0' => 'Age/V50',
'age=5.1' => 'Age/V51',
'age=5.2' => 'Age/V52',
'age=6' => 'Age/V60',
'age=6.0' => 'Age/V60',
'age=6.1' => 'Age/V61',
'age=6.2' => '#/76',
'age=6.3' => '#/77',
'age=7' => 'Age/V70',
'age=7.0' => 'Age/V70',
'ccc=0' => 'Ccc/NR',
'ccc=1' => 'Ccc/OV',
'ccc=10' => '#/23',
'ccc=103' => '#/52',
'ccc=107' => '#/53',
'ccc=11' => '#/24',
'ccc=118' => '#/54',
'ccc=12' => '#/25',
'ccc=122' => '#/55',
'ccc=129' => '#/56',
'ccc=13' => '#/26',
'ccc=130' => '#/57',
'ccc=132' => '#/58',
'ccc=133' => '#/0',
'ccc=14' => '#/27',
'ccc=15' => '#/28',
'ccc=16' => '#/29',
'ccc=17' => '#/30',
'ccc=18' => '#/31',
'ccc=19' => '#/32',
'ccc=20' => '#/33',
'ccc=200' => '#/0',
'ccc=202' => '#/22',
'ccc=21' => '#/34',
'ccc=214' => '#/21',
'ccc=216' => 'Ccc/ATAR',
'ccc=218' => '#/17',
'ccc=22' => '#/35',
'ccc=220' => 'Ccc/B',
'ccc=222' => 'Ccc/BR',
'ccc=224' => '#/14',
'ccc=226' => '#/15',
'ccc=228' => '#/16',
'ccc=23' => '#/36',
'ccc=230' => 'Ccc/A',
'ccc=232' => 'Ccc/AR',
'ccc=233' => 'Ccc/DB',
'ccc=234' => '#/18',
'ccc=24' => '#/37',
'ccc=240' => '#/19',
'ccc=25' => '#/38',
'ccc=26' => '#/39',
'ccc=27' => '#/40',
'ccc=28' => '#/41',
'ccc=29' => '#/42',
'ccc=30' => '#/43',
'ccc=31' => '#/44',
'ccc=32' => '#/45',
'ccc=33' => '#/46',
'ccc=34' => '#/47',
'ccc=35' => '#/48',
'ccc=36' => '#/49',
'ccc=7' => 'Ccc/NK',
'ccc=8' => '#/20',
'ccc=84' => '#/50',
'ccc=9' => 'Ccc/VR',
'ccc=91' => '#/51',
'in=1.1' => 'Age/V11',
'in=2' => 'In/2_0',
'in=2.0' => 'In/2_0',
'in=2.1' => 'In/2_1',
'in=3' => 'In/3_0',
'in=3.0' => 'In/3_0',
'in=3.1' => 'In/3_1',
'in=3.2' => 'In/3_2',
'in=4' => 'In/4_0',
'in=4.0' => 'In/4_0',
'in=4.1' => 'In/4_1',
'in=5' => 'In/5_0',
'in=5.0' => 'In/5_0',
'in=5.1' => 'In/5_1',
'in=5.2' => 'In/5_2',
'in=6' => 'In/6_0',
'in=6.0' => 'In/6_0',
'in=6.1' => 'In/6_1',
'in=6.2' => 'In/6_2',
'in=6.3' => 'In/6_3',
'in=7' => 'In/7_0',
'in=7.0' => 'In/7_0',
'nv=-1/2' => '#/478',
'nv=0' => 'Nv/0',
'nv=1' => 'Nv/1',
'nv=1/10' => '#/479',
'nv=1/16' => '#/480',
'nv=1/2' => 'Nv/1_2',
'nv=1/3' => 'Nv/1_3',
'nv=1/4' => 'Nv/1_4',
'nv=1/5' => '#/458',
'nv=1/6' => '#/459',
'nv=1/7' => '#/460',
'nv=1/8' => 'Nv/1_8',
'nv=1/9' => '#/461',
'nv=10' => 'Nv/10',
'nv=100' => 'Nv/100',
'nv=1000' => 'Nv/1000',
'nv=10000' => 'Nv/10000',
'nv=100000' => '#/500',
'nv=1000000' => '#/503',
'nv=100000000' => '#/504',
'nv=10000000000' => '#/505',
'nv=1000000000000' => '#/506',
'nv=11' => 'Nv/11',
'nv=11/2' => '#/481',
'nv=12' => 'Nv/12',
'nv=13' => 'Nv/13',
'nv=13/2' => '#/482',
'nv=14' => 'Nv/14',
'nv=15' => 'Nv/15',
'nv=15/2' => '#/483',
'nv=16' => 'Nv/16',
'nv=17' => 'Nv/17',
'nv=17/2' => '#/484',
'nv=18' => 'Nv/18',
'nv=19' => 'Nv/19',
'nv=2' => 'Nv/2',
'nv=2/3' => 'Nv/2_3',
'nv=2/5' => '#/462',
'nv=20' => 'Nv/20',
'nv=200' => '#/463',
'nv=2000' => '#/485',
'nv=20000' => '#/493',
'nv=21' => '#/431',
'nv=216000' => '#/501',
'nv=22' => '#/432',
'nv=23' => '#/433',
'nv=24' => '#/434',
'nv=25' => '#/435',
'nv=26' => '#/436',
'nv=27' => '#/437',
'nv=28' => '#/438',
'nv=29' => '#/439',
'nv=3' => 'Nv/3',
'nv=3/16' => '#/486',
'nv=3/2' => '#/464',
'nv=3/4' => 'Nv/3_4',
'nv=3/5' => '#/465',
'nv=3/8' => '#/466',
'nv=30' => 'Nv/30',
'nv=300' => 'Nv/300',
'nv=3000' => '#/487',
'nv=30000' => '#/494',
'nv=31' => '#/440',
'nv=32' => '#/441',
'nv=33' => '#/442',
'nv=34' => '#/443',
'nv=35' => '#/444',
'nv=36' => '#/445',
'nv=37' => '#/446',
'nv=38' => '#/447',
'nv=39' => '#/448',
'nv=4' => 'Nv/4',
'nv=4/5' => '#/467',
'nv=40' => 'Nv/40',
'nv=400' => '#/468',
'nv=4000' => '#/488',
'nv=40000' => '#/495',
'nv=41' => '#/449',
'nv=42' => '#/450',
'nv=43' => '#/451',
'nv=432000' => '#/502',
'nv=44' => '#/452',
'nv=45' => '#/453',
'nv=46' => '#/454',
'nv=47' => '#/455',
'nv=48' => '#/456',
'nv=49' => '#/457',
'nv=5' => 'Nv/5',
'nv=5/2' => '#/469',
'nv=5/6' => '#/470',
'nv=5/8' => '#/471',
'nv=50' => 'Nv/50',
'nv=500' => 'Nv/500',
'nv=5000' => 'Nv/5000',
'nv=50000' => 'Nv/50000',
'nv=6' => 'Nv/6',
'nv=60' => 'Nv/60',
'nv=600' => '#/472',
'nv=6000' => '#/489',
'nv=60000' => '#/496',
'nv=7' => 'Nv/7',
'nv=7/2' => '#/473',
'nv=7/8' => '#/474',
'nv=70' => 'Nv/70',
'nv=700' => '#/475',
'nv=7000' => '#/490',
'nv=70000' => '#/497',
'nv=8' => 'Nv/8',
'nv=80' => 'Nv/80',
'nv=800' => '#/476',
'nv=8000' => '#/491',
'nv=80000' => '#/498',
'nv=9' => 'Nv/9',
'nv=9/2' => '#/477',
'nv=90' => 'Nv/90',
'nv=900' => 'Nv/900',
'nv=9000' => '#/492',
'nv=90000' => '#/499',
);

%utf8::loose_to_file_of = (
'aegeannumbers' => '#/281',
'age=na' => 'Age/NA',
'age=unassigned' => 'Age/NA',
'age=v11' => 'Age/V11',
'age=v20' => 'Age/V20',
'age=v21' => '#/75',
'age=v30' => 'Age/V30',
'age=v31' => 'Age/V31',
'age=v32' => 'Age/V32',
'age=v40' => 'Age/V40',
'age=v41' => 'Age/V41',
'age=v50' => 'Age/V50',
'age=v51' => 'Age/V51',
'age=v52' => 'Age/V52',
'age=v60' => 'Age/V60',
'age=v61' => 'Age/V61',
'age=v62' => '#/76',
'age=v63' => '#/77',
'age=v70' => 'Age/V70',
'aghb' => '#/511',
'ahex' => '#/59',
'ahex=f' => '#/!59',
'ahex=false' => '#/!59',
'ahex=n' => '#/!59',
'ahex=no' => '#/!59',
'ahex=t' => '#/59',
'ahex=true' => '#/59',
'ahex=y' => '#/59',
'ahex=yes' => '#/59',
'alchemical' => '#/229',
'alchemicalsymbols' => '#/229',
'all' => '#/1',
'alnum' => 'Perl/Alnum',
'alpha' => 'Alpha/Y',
'alpha=f' => '!Alpha/Y',
'alpha=false' => '!Alpha/Y',
'alpha=n' => '!Alpha/Y',
'alpha=no' => '!Alpha/Y',
'alpha=t' => 'Alpha/Y',
'alpha=true' => 'Alpha/Y',
'alpha=y' => 'Alpha/Y',
'alpha=yes' => 'Alpha/Y',
'alphabetic' => 'Alpha/Y',
'alphabeticpf' => '#/271',
'alphabeticpresentationforms' => '#/271',
'ancientgreekmusic' => '#/320',
'ancientgreekmusicalnotation' => '#/320',
'ancientgreeknumbers' => '#/327',
'ancientsymbols' => '#/288',
'any' => '#/2',
'arab' => 'Sc/Arab',
'arabic' => 'Sc/Arab',
'arabicexta' => '#/230',
'arabicextendeda' => '#/230',
'arabicmath' => '#/231',
'arabicmathematicalalphabeticsymbols' => '#/231',
'arabicpfa' => '#/205',
'arabicpfb' => '#/206',
'arabicpresentationformsa' => '#/205',
'arabicpresentationformsb' => '#/206',
'arabicsup' => '#/207',
'arabicsupplement' => '#/207',
'armenian' => 'Sc/Armn',
'armi' => '#/512',
'armn' => 'Sc/Armn',
'arrows' => '#/122',
'ascii' => '#/106',
'asciihexdigit' => '#/59',
'assigned' => 'Perl/Assigned',
'avestan' => '#/513',
'avst' => '#/513',
'bali' => '#/514',
'balinese' => '#/514',
'bamu' => '#/515',
'bamum' => '#/515',
'bamumsup' => '#/180',
'bamumsupplement' => '#/180',
'basiclatin' => '#/106',
'bass' => '#/516',
'bassavah' => '#/516',
'batak' => '#/517',
'batk' => '#/517',
'bc=al' => 'Bc/AL',
'bc=an' => 'Bc/AN',
'bc=arabicletter' => 'Bc/AL',
'bc=arabicnumber' => 'Bc/AN',
'bc=b' => 'Bc/B',
'bc=bn' => 'Bc/BN',
'bc=boundaryneutral' => 'Bc/BN',
'bc=commonseparator' => 'Bc/CS',
'bc=cs' => 'Bc/CS',
'bc=en' => 'Bc/EN',
'bc=es' => 'Bc/ES',
'bc=et' => 'Bc/ET',
'bc=europeannumber' => 'Bc/EN',
'bc=europeanseparator' => 'Bc/ES',
'bc=europeanterminator' => 'Bc/ET',
'bc=firststrongisolate' => '#/79',
'bc=fsi' => '#/79',
'bc=l' => 'Bc/L',
'bc=lefttoright' => 'Bc/L',
'bc=lefttorightembedding' => '#/80',
'bc=lefttorightisolate' => '#/81',
'bc=lefttorightoverride' => '#/82',
'bc=lre' => '#/80',
'bc=lri' => '#/81',
'bc=lro' => '#/82',
'bc=nonspacingmark' => 'Bc/NSM',
'bc=nsm' => 'Bc/NSM',
'bc=on' => 'Bc/ON',
'bc=otherneutral' => 'Bc/ON',
'bc=paragraphseparator' => 'Bc/B',
'bc=pdf' => '#/83',
'bc=pdi' => '#/84',
'bc=popdirectionalformat' => '#/83',
'bc=popdirectionalisolate' => '#/84',
'bc=r' => 'Bc/R',
'bc=righttoleft' => 'Bc/R',
'bc=righttoleftembedding' => '#/85',
'bc=righttoleftisolate' => '#/86',
'bc=righttoleftoverride' => '#/87',
'bc=rle' => '#/85',
'bc=rli' => '#/86',
'bc=rlo' => '#/87',
'bc=s' => '#/78',
'bc=segmentseparator' => '#/78',
'bc=whitespace' => 'Bc/WS',
'bc=ws' => 'Bc/WS',
'beng' => 'Sc/Beng',
'bengali' => 'Sc/Beng',
'bidic' => 'BidiC/Y',
'bidic=f' => '!BidiC/Y',
'bidic=false' => '!BidiC/Y',
'bidic=n' => '!BidiC/Y',
'bidic=no' => '!BidiC/Y',
'bidic=t' => 'BidiC/Y',
'bidic=true' => 'BidiC/Y',
'bidic=y' => 'BidiC/Y',
'bidic=yes' => 'BidiC/Y',
'bidicontrol' => 'BidiC/Y',
'bidim' => 'BidiM/Y',
'bidim=f' => '!BidiM/Y',
'bidim=false' => '!BidiM/Y',
'bidim=n' => '!BidiM/Y',
'bidim=no' => '!BidiM/Y',
'bidim=t' => 'BidiM/Y',
'bidim=true' => 'BidiM/Y',
'bidim=y' => 'BidiM/Y',
'bidim=yes' => 'BidiM/Y',
'bidimirrored' => 'BidiM/Y',
'blank' => 'Perl/Blank',
'blk=aegeannumbers' => '#/281',
'blk=alchemical' => '#/229',
'blk=alchemicalsymbols' => '#/229',
'blk=alphabeticpf' => '#/271',
'blk=alphabeticpresentationforms' => '#/271',
'blk=ancientgreekmusic' => '#/320',
'blk=ancientgreekmusicalnotation' => '#/320',
'blk=ancientgreeknumbers' => '#/327',
'blk=ancientsymbols' => '#/288',
'blk=arabic' => '#/121',
'blk=arabicexta' => '#/230',
'blk=arabicextendeda' => '#/230',
'blk=arabicmath' => '#/231',
'blk=arabicmathematicalalphabeticsymbols' => '#/231',
'blk=arabicpfa' => '#/205',
'blk=arabicpfb' => '#/206',
'blk=arabicpresentationformsa' => '#/205',
'blk=arabicpresentationformsb' => '#/206',
'blk=arabicsup' => '#/207',
'blk=arabicsupplement' => '#/207',
'blk=armenian' => '#/178',
'blk=arrows' => '#/122',
'blk=ascii' => '#/106',
'blk=avestan' => '#/145',
'blk=balinese' => '#/179',
'blk=bamum' => '#/107',
'blk=bamumsup' => '#/180',
'blk=bamumsupplement' => '#/180',
'blk=basiclatin' => '#/106',
'blk=bassavah' => '#/181',
'blk=batak' => '#/108',
'blk=bengali' => '#/146',
'blk=blockelements' => '#/282',
'blk=bopomofo' => '#/182',
'blk=bopomofoext' => '#/250',
'blk=bopomofoextended' => '#/250',
'blk=boxdrawing' => '#/232',
'blk=brahmi' => '#/123',
'blk=braille' => '#/147',
'blk=braillepatterns' => '#/147',
'blk=buginese' => '#/183',
'blk=buhid' => '#/109',
'blk=byzantinemusic' => '#/289',
'blk=byzantinemusicalsymbols' => '#/289',
'blk=canadiansyllabics' => '#/105',
'blk=carian' => '#/124',
'blk=caucasianalbanian' => '#/321',
'blk=chakma' => '#/125',
'blk=cham' => '#/97',
'blk=cherokee' => '#/184',
'blk=cjk' => '#/89',
'blk=cjkcompat' => '#/208',
'blk=cjkcompatforms' => '#/290',
'blk=cjkcompatibility' => '#/208',
'blk=cjkcompatibilityforms' => '#/290',
'blk=cjkcompatibilityideographs' => '#/328',
'blk=cjkcompatibilityideographssupplement' => '#/336',
'blk=cjkcompatideographs' => '#/328',
'blk=cjkcompatideographssup' => '#/336',
'blk=cjkexta' => '#/148',
'blk=cjkextb' => '#/149',
'blk=cjkextc' => '#/150',
'blk=cjkextd' => '#/151',
'blk=cjkradicalssup' => '#/291',
'blk=cjkradicalssupplement' => '#/291',
'blk=cjkstrokes' => '#/233',
'blk=cjksymbols' => '#/234',
'blk=cjksymbolsandpunctuation' => '#/234',
'blk=cjkunifiedideographs' => '#/89',
'blk=cjkunifiedideographsextensiona' => '#/148',
'blk=cjkunifiedideographsextensionb' => '#/149',
'blk=cjkunifiedideographsextensionc' => '#/150',
'blk=cjkunifiedideographsextensiond' => '#/151',
'blk=combiningdiacriticalmarks' => '#/274',
'blk=combiningdiacriticalmarksextended' => '#/299',
'blk=combiningdiacriticalmarksforsymbols' => '#/337',
'blk=combiningdiacriticalmarkssupplement' => '#/300',
'blk=combininghalfmarks' => '#/211',
'blk=combiningmarksforsymbols' => '#/337',
'blk=commonindicnumberforms' => '#/314',
'blk=compatjamo' => '#/235',
'blk=controlpictures' => '#/297',
'blk=coptic' => '#/126',
'blk=copticepactnumbers' => '#/323',
'blk=countingrod' => '#/251',
'blk=countingrodnumerals' => '#/251',
'blk=cuneiform' => '#/209',
'blk=cuneiformnumbers' => '#/309',
'blk=cuneiformnumbersandpunctuation' => '#/309',
'blk=currencysymbols' => '#/298',
'blk=cypriotsyllabary' => '#/310',
'blk=cyrillic' => '#/185',
'blk=cyrillicexta' => '#/272',
'blk=cyrillicextb' => '#/273',
'blk=cyrillicextendeda' => '#/272',
'blk=cyrillicextendedb' => '#/273',
'blk=cyrillicsup' => '#/252',
'blk=cyrillicsupplement' => '#/252',
'blk=cyrillicsupplementary' => '#/252',
'blk=deseret' => '#/152',
'blk=devanagari' => '#/236',
'blk=devanagariext' => '#/283',
'blk=devanagariextended' => '#/283',
'blk=diacriticals' => '#/274',
'blk=diacriticalsext' => '#/299',
'blk=diacriticalsforsymbols' => '#/337',
'blk=diacriticalssup' => '#/300',
'blk=dingbats' => '#/186',
'blk=domino' => '#/127',
'blk=dominotiles' => '#/127',
'blk=duployan' => '#/187',
'blk=egyptianhieroglyphs' => '#/329',
'blk=elbasan' => '#/153',
'blk=emoticons' => '#/210',
'blk=enclosedalphanum' => '#/311',
'blk=enclosedalphanumerics' => '#/311',
'blk=enclosedalphanumericsupplement' => '#/330',
'blk=enclosedalphanumsup' => '#/330',
'blk=enclosedcjk' => '#/253',
'blk=enclosedcjklettersandmonths' => '#/253',
'blk=enclosedideographicsup' => '#/338',
'blk=enclosedideographicsupplement' => '#/338',
'blk=ethiopic' => '#/188',
'blk=ethiopicext' => '#/254',
'blk=ethiopicexta' => '#/275',
'blk=ethiopicextended' => '#/254',
'blk=ethiopicextendeda' => '#/275',
'blk=ethiopicsup' => '#/255',
'blk=ethiopicsupplement' => '#/255',
'blk=generalpunctuation' => '#/265',
'blk=geometricshapes' => '#/301',
'blk=geometricshapesext' => '#/324',
'blk=geometricshapesextended' => '#/324',
'blk=georgian' => '#/189',
'blk=georgiansup' => '#/256',
'blk=georgiansupplement' => '#/256',
'blk=glagolitic' => '#/237',
'blk=gothic' => '#/128',
'blk=grantha' => '#/154',
'blk=greek' => '#/110',
'blk=greekandcoptic' => '#/110',
'blk=greekext' => '#/190',
'blk=greekextended' => '#/190',
'blk=gujarati' => '#/191',
'blk=gurmukhi' => '#/192',
'blk=halfandfullforms' => '#/312',
'blk=halfmarks' => '#/211',
'blk=halfwidthandfullwidthforms' => '#/312',
'blk=hangul' => '#/129',
'blk=hangulcompatibilityjamo' => '#/235',
'blk=hanguljamo' => '#/98',
'blk=hanguljamoextendeda' => '#/194',
'blk=hanguljamoextendedb' => '#/195',
'blk=hangulsyllables' => '#/129',
'blk=hanunoo' => '#/155',
'blk=hebrew' => '#/130',
'blk=highprivateusesurrogates' => '#/313',
'blk=highpusurrogates' => '#/313',
'blk=highsurrogates' => '#/292',
'blk=hiragana' => '#/193',
'blk=idc' => '#/90',
'blk=ideographicdescriptioncharacters' => '#/90',
'blk=imperialaramaic' => '#/302',
'blk=indicnumberforms' => '#/314',
'blk=inscriptionalpahlavi' => '#/333',
'blk=inscriptionalparthian' => '#/334',
'blk=ipaext' => '#/131',
'blk=ipaextensions' => '#/131',
'blk=jamo' => '#/98',
'blk=jamoexta' => '#/194',
'blk=jamoextb' => '#/195',
'blk=javanese' => '#/196',
'blk=kaithi' => '#/132',
'blk=kanasup' => '#/156',
'blk=kanasupplement' => '#/156',
'blk=kanbun' => '#/133',
'blk=kangxi' => '#/134',
'blk=kangxiradicals' => '#/134',
'blk=kannada' => '#/157',
'blk=katakana' => '#/197',
'blk=katakanaext' => '#/257',
'blk=katakanaphoneticextensions' => '#/257',
'blk=kayahli' => '#/158',
'blk=kharoshthi' => '#/238',
'blk=khmer' => '#/111',
'blk=khmersymbols' => '#/276',
'blk=khojki' => '#/135',
'blk=khudawadi' => '#/212',
'blk=lao' => '#/91',
'blk=latin1' => '#/136',
'blk=latin1sup' => '#/136',
'blk=latin1supplement' => '#/136',
'blk=latinexta' => '#/213',
'blk=latinextadditional' => '#/325',
'blk=latinextb' => '#/214',
'blk=latinextc' => '#/215',
'blk=latinextd' => '#/216',
'blk=latinexte' => '#/217',
'blk=latinextendeda' => '#/213',
'blk=latinextendedadditional' => '#/325',
'blk=latinextendedb' => '#/214',
'blk=latinextendedc' => '#/215',
'blk=latinextendedd' => '#/216',
'blk=latinextendede' => '#/217',
'blk=lepcha' => '#/137',
'blk=letterlikesymbols' => '#/322',
'blk=limbu' => '#/112',
'blk=lineara' => '#/159',
'blk=linearbideograms' => '#/315',
'blk=linearbsyllabary' => '#/316',
'blk=lisu' => '#/99',
'blk=lowsurrogates' => '#/284',
'blk=lycian' => '#/138',
'blk=lydian' => '#/139',
'blk=mahajani' => '#/198',
'blk=mahjong' => '#/160',
'blk=mahjongtiles' => '#/160',
'blk=malayalam' => '#/218',
'blk=mandaic' => '#/161',
'blk=manichaean' => '#/239',
'blk=mathalphanum' => '#/277',
'blk=mathematicalalphanumericsymbols' => '#/277',
'blk=mathematicaloperators' => '#/285',
'blk=mathoperators' => '#/285',
'blk=meeteimayek' => '#/258',
'blk=meeteimayekext' => '#/293',
'blk=meeteimayekextensions' => '#/293',
'blk=mendekikakui' => '#/278',
'blk=meroiticcursive' => '#/303',
'blk=meroitichieroglyphs' => '#/331',
'blk=miao' => '#/100',
'blk=miscarrows' => '#/240',
'blk=miscellaneousmathematicalsymbolsa' => '#/317',
'blk=miscellaneousmathematicalsymbolsb' => '#/318',
'blk=miscellaneoussymbols' => '#/259',
'blk=miscellaneoussymbolsandarrows' => '#/240',
'blk=miscellaneoussymbolsandpictographs' => '#/304',
'blk=miscellaneoustechnical' => '#/286',
'blk=miscmathsymbolsa' => '#/317',
'blk=miscmathsymbolsb' => '#/318',
'blk=miscpictographs' => '#/304',
'blk=miscsymbols' => '#/259',
'blk=misctechnical' => '#/286',
'blk=modi' => '#/101',
'blk=modifierletters' => '#/305',
'blk=modifiertoneletters' => '#/332',
'blk=mongolian' => '#/219',
'blk=mro' => '#/92',
'blk=music' => '#/113',
'blk=musicalsymbols' => '#/113',
'blk=myanmar' => '#/162',
'blk=myanmarexta' => '#/260',
'blk=myanmarextb' => '#/261',
'blk=myanmarextendeda' => '#/260',
'blk=myanmarextendedb' => '#/261',
'blk=nabataean' => '#/220',
'blk=nb' => 'Blk/NB',
'blk=newtailue' => '#/221',
'blk=nko' => '#/93',
'blk=noblock' => 'Blk/NB',
'blk=numberforms' => '#/262',
'blk=ocr' => '#/94',
'blk=ogham' => '#/114',
'blk=olchiki' => '#/163',
'blk=olditalic' => '#/222',
'blk=oldnortharabian' => '#/306',
'blk=oldpermic' => '#/223',
'blk=oldpersian' => '#/241',
'blk=oldsoutharabian' => '#/307',
'blk=oldturkic' => '#/224',
'blk=opticalcharacterrecognition' => '#/94',
'blk=oriya' => '#/115',
'blk=ornamentaldingbats' => '#/326',
'blk=osmanya' => '#/164',
'blk=pahawhhmong' => '#/263',
'blk=palmyrene' => '#/225',
'blk=paucinhau' => '#/226',
'blk=phagspa' => '#/165',
'blk=phaistos' => '#/199',
'blk=phaistosdisc' => '#/199',
'blk=phoenician' => '#/242',
'blk=phoneticext' => '#/264',
'blk=phoneticextensions' => '#/264',
'blk=phoneticextensionssupplement' => '#/294',
'blk=phoneticextsup' => '#/294',
'blk=playingcards' => '#/279',
'blk=privateuse' => '#/95',
'blk=privateusearea' => '#/95',
'blk=psalterpahlavi' => '#/295',
'blk=pua' => '#/95',
'blk=punctuation' => '#/265',
'blk=rejang' => '#/140',
'blk=rumi' => '#/102',
'blk=ruminumeralsymbols' => '#/102',
'blk=runic' => '#/116',
'blk=samaritan' => '#/227',
'blk=saurashtra' => '#/243',
'blk=sharada' => '#/166',
'blk=shavian' => '#/167',
'blk=shorthandformatcontrols' => '#/339',
'blk=siddham' => '#/168',
'blk=sinhala' => '#/169',
'blk=sinhalaarchaicnumbers' => '#/335',
'blk=smallforms' => '#/244',
'blk=smallformvariants' => '#/244',
'blk=sorasompeng' => '#/266',
'blk=spacingmodifierletters' => '#/305',
'blk=specials' => '#/200',
'blk=sundanese' => '#/228',
'blk=sundanesesup' => '#/280',
'blk=sundanesesupplement' => '#/280',
'blk=suparrowsa' => '#/245',
'blk=suparrowsb' => '#/246',
'blk=suparrowsc' => '#/247',
'blk=superandsub' => '#/267',
'blk=superscriptsandsubscripts' => '#/267',
'blk=supmathoperators' => '#/319',
'blk=supplementalarrowsa' => '#/245',
'blk=supplementalarrowsb' => '#/246',
'blk=supplementalarrowsc' => '#/247',
'blk=supplementalmathematicaloperators' => '#/319',
'blk=supplementalpunctuation' => '#/296',
'blk=supplementaryprivateuseareaa' => '#/170',
'blk=supplementaryprivateuseareab' => '#/171',
'blk=suppuaa' => '#/170',
'blk=suppuab' => '#/171',
'blk=suppunctuation' => '#/296',
'blk=sylotinagri' => '#/268',
'blk=syriac' => '#/141',
'blk=tagalog' => '#/172',
'blk=tagbanwa' => '#/201',
'blk=tags' => '#/103',
'blk=taile' => '#/117',
'blk=taitham' => '#/173',
'blk=taiviet' => '#/174',
'blk=taixuanjing' => '#/269',
'blk=taixuanjingsymbols' => '#/269',
'blk=takri' => '#/118',
'blk=tamil' => '#/119',
'blk=telugu' => '#/142',
'blk=thaana' => '#/143',
'blk=thai' => '#/104',
'blk=tibetan' => '#/175',
'blk=tifinagh' => '#/202',
'blk=tirhuta' => '#/176',
'blk=transportandmap' => '#/308',
'blk=transportandmapsymbols' => '#/308',
'blk=ucas' => '#/105',
'blk=ucasext' => '#/177',
'blk=ugaritic' => '#/203',
'blk=unifiedcanadianaboriginalsyllabics' => '#/105',
'blk=unifiedcanadianaboriginalsyllabicsextended' => '#/177',
'blk=vai' => '#/96',
'blk=variationselectors' => '#/88',
'blk=variationselectorssupplement' => '#/120',
'blk=vedicext' => '#/204',
'blk=vedicextensions' => '#/204',
'blk=verticalforms' => '#/287',
'blk=vs' => '#/88',
'blk=vssup' => '#/120',
'blk=warangciti' => '#/248',
'blk=yijing' => '#/144',
'blk=yijinghexagramsymbols' => '#/144',
'blk=yiradicals' => '#/249',
'blk=yisyllables' => '#/270',
'blockelements' => '#/282',
'bopo' => '#/518',
'bopomofo' => '#/518',
'bopomofoext' => '#/250',
'bopomofoextended' => '#/250',
'boxdrawing' => '#/232',
'bpt=c' => 'Bpt/C',
'bpt=close' => 'Bpt/C',
'bpt=n' => 'Bpt/N',
'bpt=none' => 'Bpt/N',
'bpt=o' => 'Bpt/O',
'bpt=open' => 'Bpt/O',
'brah' => '#/519',
'brahmi' => '#/519',
'brai' => '#/147',
'braille' => '#/147',
'braillepatterns' => '#/147',
'bugi' => '#/520',
'buginese' => '#/520',
'buhd' => '#/521',
'buhid' => '#/521',
'byzantinemusic' => '#/289',
'byzantinemusicalsymbols' => '#/289',
'c' => 'Gc/C',
'cakm' => '#/522',
'canadianaboriginal' => '#/523',
'canadiansyllabics' => '#/105',
'cans' => '#/523',
'cari' => '#/524',
'carian' => '#/524',
'cased' => 'Cased/Y',
'cased=f' => '!Cased/Y',
'cased=false' => '!Cased/Y',
'cased=n' => '!Cased/Y',
'cased=no' => '!Cased/Y',
'cased=t' => 'Cased/Y',
'cased=true' => 'Cased/Y',
'cased=y' => 'Cased/Y',
'cased=yes' => 'Cased/Y',
'casedletter' => 'Gc/LC',
'caseignorable' => 'CI/Y',
'caucasianalbanian' => '#/511',
'cc' => '#/343',
'ccc=a' => 'Ccc/A',
'ccc=above' => 'Ccc/A',
'ccc=aboveleft' => '#/16',
'ccc=aboveright' => 'Ccc/AR',
'ccc=al' => '#/16',
'ccc=ar' => 'Ccc/AR',
'ccc=ata' => '#/21',
'ccc=atar' => 'Ccc/ATAR',
'ccc=atb' => '#/22',
'ccc=atbl' => '#/0',
'ccc=attachedabove' => '#/21',
'ccc=attachedaboveright' => 'Ccc/ATAR',
'ccc=attachedbelow' => '#/22',
'ccc=attachedbelowleft' => '#/0',
'ccc=b' => 'Ccc/B',
'ccc=below' => 'Ccc/B',
'ccc=belowleft' => '#/17',
'ccc=belowright' => 'Ccc/BR',
'ccc=bl' => '#/17',
'ccc=br' => 'Ccc/BR',
'ccc=ccc10' => '#/23',
'ccc=ccc103' => '#/52',
'ccc=ccc107' => '#/53',
'ccc=ccc11' => '#/24',
'ccc=ccc118' => '#/54',
'ccc=ccc12' => '#/25',
'ccc=ccc122' => '#/55',
'ccc=ccc129' => '#/56',
'ccc=ccc13' => '#/26',
'ccc=ccc130' => '#/57',
'ccc=ccc132' => '#/58',
'ccc=ccc133' => '#/0',
'ccc=ccc14' => '#/27',
'ccc=ccc15' => '#/28',
'ccc=ccc16' => '#/29',
'ccc=ccc17' => '#/30',
'ccc=ccc18' => '#/31',
'ccc=ccc19' => '#/32',
'ccc=ccc20' => '#/33',
'ccc=ccc21' => '#/34',
'ccc=ccc22' => '#/35',
'ccc=ccc23' => '#/36',
'ccc=ccc24' => '#/37',
'ccc=ccc25' => '#/38',
'ccc=ccc26' => '#/39',
'ccc=ccc27' => '#/40',
'ccc=ccc28' => '#/41',
'ccc=ccc29' => '#/42',
'ccc=ccc30' => '#/43',
'ccc=ccc31' => '#/44',
'ccc=ccc32' => '#/45',
'ccc=ccc33' => '#/46',
'ccc=ccc34' => '#/47',
'ccc=ccc35' => '#/48',
'ccc=ccc36' => '#/49',
'ccc=ccc84' => '#/50',
'ccc=ccc91' => '#/51',
'ccc=da' => '#/18',
'ccc=db' => 'Ccc/DB',
'ccc=doubleabove' => '#/18',
'ccc=doublebelow' => 'Ccc/DB',
'ccc=iotasubscript' => '#/19',
'ccc=is' => '#/19',
'ccc=kanavoicing' => '#/20',
'ccc=kv' => '#/20',
'ccc=l' => '#/14',
'ccc=left' => '#/14',
'ccc=nk' => 'Ccc/NK',
'ccc=notreordered' => 'Ccc/NR',
'ccc=nr' => 'Ccc/NR',
'ccc=nukta' => 'Ccc/NK',
'ccc=ov' => 'Ccc/OV',
'ccc=overlay' => 'Ccc/OV',
'ccc=r' => '#/15',
'ccc=right' => '#/15',
'ccc=virama' => 'Ccc/VR',
'ccc=vr' => 'Ccc/VR',
'ce' => 'CE/Y',
'ce=f' => '!CE/Y',
'ce=false' => '!CE/Y',
'ce=n' => '!CE/Y',
'ce=no' => '!CE/Y',
'ce=t' => 'CE/Y',
'ce=true' => 'CE/Y',
'ce=y' => 'CE/Y',
'ce=yes' => 'CE/Y',
'cf' => 'Gc/Cf',
'chakma' => '#/522',
'cham' => 'Sc/Cham',
'changeswhencasefolded' => 'CWCF/Y',
'changeswhencasemapped' => 'CWCM/Y',
'changeswhenlowercased' => 'CWL/Y',
'changeswhennfkccasefolded' => 'CWKCF/Y',
'changeswhentitlecased' => 'CWT/Y',
'changeswhenuppercased' => 'CWU/Y',
'cher' => '#/525',
'cherokee' => '#/525',
'ci' => 'CI/Y',
'ci=f' => '!CI/Y',
'ci=false' => '!CI/Y',
'ci=n' => '!CI/Y',
'ci=no' => '!CI/Y',
'ci=t' => 'CI/Y',
'ci=true' => 'CI/Y',
'ci=y' => 'CI/Y',
'ci=yes' => 'CI/Y',
'cjk' => '#/89',
'cjkcompat' => '#/208',
'cjkcompatforms' => '#/290',
'cjkcompatibility' => '#/208',
'cjkcompatibilityforms' => '#/290',
'cjkcompatibilityideographs' => '#/328',
'cjkcompatibilityideographssupplement' => '#/336',
'cjkcompatideographs' => '#/328',
'cjkcompatideographssup' => '#/336',
'cjkexta' => '#/148',
'cjkextb' => '#/149',
'cjkextc' => '#/150',
'cjkextd' => '#/151',
'cjkradicalssup' => '#/291',
'cjkradicalssupplement' => '#/291',
'cjkstrokes' => '#/233',
'cjksymbols' => '#/234',
'cjksymbolsandpunctuation' => '#/234',
'cjkunifiedideographs' => '#/89',
'cjkunifiedideographsextensiona' => '#/148',
'cjkunifiedideographsextensionb' => '#/149',
'cjkunifiedideographsextensionc' => '#/150',
'cjkunifiedideographsextensiond' => '#/151',
'closepunctuation' => 'Gc/Pe',
'cn' => 'Gc/Cn',
'cntrl' => '#/343',
'co' => '#/344',
'combiningdiacriticalmarks' => '#/274',
'combiningdiacriticalmarksextended' => '#/299',
'combiningdiacriticalmarksforsymbols' => '#/337',
'combiningdiacriticalmarkssupplement' => '#/300',
'combininghalfmarks' => '#/211',
'combiningmark' => 'Gc/M',
'combiningmarksforsymbols' => '#/337',
'common' => 'Sc/Zyyy',
'commonindicnumberforms' => '#/314',
'compatjamo' => '#/235',
'compex' => 'CompEx/Y',
'compex=f' => '!CompEx/Y',
'compex=false' => '!CompEx/Y',
'compex=n' => '!CompEx/Y',
'compex=no' => '!CompEx/Y',
'compex=t' => 'CompEx/Y',
'compex=true' => 'CompEx/Y',
'compex=y' => 'CompEx/Y',
'compex=yes' => 'CompEx/Y',
'compositionexclusion' => 'CE/Y',
'connectorpunctuation' => 'WB/EX',
'control' => '#/343',
'controlpictures' => '#/297',
'copt' => '#/526',
'coptic' => '#/526',
'copticepactnumbers' => '#/323',
'countingrod' => '#/251',
'countingrodnumerals' => '#/251',
'cprt' => 'Sc/Cprt',
'cs' => '#/345',
'cuneiform' => '#/584',
'cuneiformnumbers' => '#/309',
'cuneiformnumbersandpunctuation' => '#/309',
'currencysymbol' => 'Gc/Sc',
'currencysymbols' => '#/298',
'cwcf' => 'CWCF/Y',
'cwcf=f' => '!CWCF/Y',
'cwcf=false' => '!CWCF/Y',
'cwcf=n' => '!CWCF/Y',
'cwcf=no' => '!CWCF/Y',
'cwcf=t' => 'CWCF/Y',
'cwcf=true' => 'CWCF/Y',
'cwcf=y' => 'CWCF/Y',
'cwcf=yes' => 'CWCF/Y',
'cwcm' => 'CWCM/Y',
'cwcm=f' => '!CWCM/Y',
'cwcm=false' => '!CWCM/Y',
'cwcm=n' => '!CWCM/Y',
'cwcm=no' => '!CWCM/Y',
'cwcm=t' => 'CWCM/Y',
'cwcm=true' => 'CWCM/Y',
'cwcm=y' => 'CWCM/Y',
'cwcm=yes' => 'CWCM/Y',
'cwkcf' => 'CWKCF/Y',
'cwkcf=f' => '!CWKCF/Y',
'cwkcf=false' => '!CWKCF/Y',
'cwkcf=n' => '!CWKCF/Y',
'cwkcf=no' => '!CWKCF/Y',
'cwkcf=t' => 'CWKCF/Y',
'cwkcf=true' => 'CWKCF/Y',
'cwkcf=y' => 'CWKCF/Y',
'cwkcf=yes' => 'CWKCF/Y',
'cwl' => 'CWL/Y',
'cwl=f' => '!CWL/Y',
'cwl=false' => '!CWL/Y',
'cwl=n' => '!CWL/Y',
'cwl=no' => '!CWL/Y',
'cwl=t' => 'CWL/Y',
'cwl=true' => 'CWL/Y',
'cwl=y' => 'CWL/Y',
'cwl=yes' => 'CWL/Y',
'cwt' => 'CWT/Y',
'cwt=f' => '!CWT/Y',
'cwt=false' => '!CWT/Y',
'cwt=n' => '!CWT/Y',
'cwt=no' => '!CWT/Y',
'cwt=t' => 'CWT/Y',
'cwt=true' => 'CWT/Y',
'cwt=y' => 'CWT/Y',
'cwt=yes' => 'CWT/Y',
'cwu' => 'CWU/Y',
'cwu=f' => '!CWU/Y',
'cwu=false' => '!CWU/Y',
'cwu=n' => '!CWU/Y',
'cwu=no' => '!CWU/Y',
'cwu=t' => 'CWU/Y',
'cwu=true' => 'CWU/Y',
'cwu=y' => 'CWU/Y',
'cwu=yes' => 'CWU/Y',
'cypriot' => 'Sc/Cprt',
'cypriotsyllabary' => '#/310',
'cyrillic' => 'Sc/Cyrl',
'cyrillicexta' => '#/272',
'cyrillicextb' => '#/273',
'cyrillicextendeda' => '#/272',
'cyrillicextendedb' => '#/273',
'cyrillicsup' => '#/252',
'cyrillicsupplement' => '#/252',
'cyrillicsupplementary' => '#/252',
'cyrl' => 'Sc/Cyrl',
'dash' => 'Dash/Y',
'dash=f' => '!Dash/Y',
'dash=false' => '!Dash/Y',
'dash=n' => '!Dash/Y',
'dash=no' => '!Dash/Y',
'dash=t' => 'Dash/Y',
'dash=true' => 'Dash/Y',
'dash=y' => 'Dash/Y',
'dash=yes' => 'Dash/Y',
'dashpunctuation' => 'Gc/Pd',
'decimalnumber' => 'Gc/Nd',
'defaultignorablecodepoint' => 'DI/Y',
'dep' => 'Dep/Y',
'dep=f' => '!Dep/Y',
'dep=false' => '!Dep/Y',
'dep=n' => '!Dep/Y',
'dep=no' => '!Dep/Y',
'dep=t' => 'Dep/Y',
'dep=true' => 'Dep/Y',
'dep=y' => 'Dep/Y',
'dep=yes' => 'Dep/Y',
'deprecated' => 'Dep/Y',
'deseret' => '#/152',
'deva' => 'Sc/Deva',
'devanagari' => 'Sc/Deva',
'devanagariext' => '#/283',
'devanagariextended' => '#/283',
'di' => 'DI/Y',
'di=f' => '!DI/Y',
'di=false' => '!DI/Y',
'di=n' => '!DI/Y',
'di=no' => '!DI/Y',
'di=t' => 'DI/Y',
'di=true' => 'DI/Y',
'di=y' => 'DI/Y',
'di=yes' => 'DI/Y',
'dia' => 'Dia/Y',
'dia=f' => '!Dia/Y',
'dia=false' => '!Dia/Y',
'dia=n' => '!Dia/Y',
'dia=no' => '!Dia/Y',
'dia=t' => 'Dia/Y',
'dia=true' => 'Dia/Y',
'dia=y' => 'Dia/Y',
'dia=yes' => 'Dia/Y',
'diacritic' => 'Dia/Y',
'diacriticals' => '#/274',
'diacriticalsext' => '#/299',
'diacriticalsforsymbols' => '#/337',
'diacriticalssup' => '#/300',
'digit' => 'Gc/Nd',
'dingbats' => '#/186',
'domino' => '#/127',
'dominotiles' => '#/127',
'dsrt' => '#/152',
'dt=can' => 'NFDQC/N',
'dt=canonical' => 'NFDQC/N',
'dt=circle' => 'Dt/Enc',
'dt=com' => 'Dt/Com',
'dt=compat' => 'Dt/Com',
'dt=enc' => 'Dt/Enc',
'dt=fin' => 'Dt/Fin',
'dt=final' => 'Dt/Fin',
'dt=font' => 'Dt/Font',
'dt=fra' => '#/340',
'dt=fraction' => '#/340',
'dt=init' => 'Dt/Init',
'dt=initial' => 'Dt/Init',
'dt=iso' => 'Dt/Iso',
'dt=isolated' => 'Dt/Iso',
'dt=med' => 'Dt/Med',
'dt=medial' => 'Dt/Med',
'dt=nar' => 'Dt/Nar',
'dt=narrow' => 'Dt/Nar',
'dt=nb' => 'Dt/Nb',
'dt=nobreak' => 'Dt/Nb',
'dt=noncanon' => 'Dt/NonCanon',
'dt=noncanonical' => 'Dt/NonCanon',
'dt=none' => 'NFKDQC/Y',
'dt=small' => '#/341',
'dt=sml' => '#/341',
'dt=sqr' => 'Dt/Sqr',
'dt=square' => 'Dt/Sqr',
'dt=sub' => 'Dt/Sub',
'dt=sup' => 'Dt/Sup',
'dt=super' => 'Dt/Sup',
'dt=vert' => 'Dt/Vert',
'dt=vertical' => 'Dt/Vert',
'dt=wide' => '#/342',
'dupl' => 'Sc/Dupl',
'duployan' => 'Sc/Dupl',
'ea=a' => 'Ea/A',
'ea=ambiguous' => 'Ea/A',
'ea=f' => '#/342',
'ea=fullwidth' => '#/342',
'ea=h' => 'Ea/H',
'ea=halfwidth' => 'Ea/H',
'ea=n' => 'Ea/N',
'ea=na' => 'Ea/Na',
'ea=narrow' => 'Ea/Na',
'ea=neutral' => 'Ea/N',
'ea=w' => 'Ea/W',
'ea=wide' => 'Ea/W',
'egyp' => '#/527',
'egyptianhieroglyphs' => '#/527',
'elba' => '#/528',
'elbasan' => '#/528',
'emoticons' => '#/210',
'enclosedalphanum' => '#/311',
'enclosedalphanumerics' => '#/311',
'enclosedalphanumericsupplement' => '#/330',
'enclosedalphanumsup' => '#/330',
'enclosedcjk' => '#/253',
'enclosedcjklettersandmonths' => '#/253',
'enclosedideographicsup' => '#/338',
'enclosedideographicsupplement' => '#/338',
'enclosingmark' => 'Gc/Me',
'ethi' => 'Sc/Ethi',
'ethiopic' => 'Sc/Ethi',
'ethiopicext' => '#/254',
'ethiopicexta' => '#/275',
'ethiopicextended' => '#/254',
'ethiopicextendeda' => '#/275',
'ethiopicsup' => '#/255',
'ethiopicsupplement' => '#/255',
'ext' => 'Ext/Y',
'ext=f' => '!Ext/Y',
'ext=false' => '!Ext/Y',
'ext=n' => '!Ext/Y',
'ext=no' => '!Ext/Y',
'ext=t' => 'Ext/Y',
'ext=true' => 'Ext/Y',
'ext=y' => 'Ext/Y',
'ext=yes' => 'Ext/Y',
'extender' => 'Ext/Y',
'finalpunctuation' => 'Gc/Pf',
'format' => 'Gc/Cf',
'fullcompositionexclusion' => 'CompEx/Y',
'gc=c' => 'Gc/C',
'gc=casedletter' => 'Gc/LC',
'gc=cc' => '#/343',
'gc=cf' => 'Gc/Cf',
'gc=closepunctuation' => 'Gc/Pe',
'gc=cn' => 'Gc/Cn',
'gc=cntrl' => '#/343',
'gc=co' => '#/344',
'gc=combiningmark' => 'Gc/M',
'gc=connectorpunctuation' => 'WB/EX',
'gc=control' => '#/343',
'gc=cs' => '#/345',
'gc=currencysymbol' => 'Gc/Sc',
'gc=dashpunctuation' => 'Gc/Pd',
'gc=decimalnumber' => 'Gc/Nd',
'gc=digit' => 'Gc/Nd',
'gc=enclosingmark' => 'Gc/Me',
'gc=finalpunctuation' => 'Gc/Pf',
'gc=format' => 'Gc/Cf',
'gc=initialpunctuation' => 'Gc/Pi',
'gc=l' => 'Gc/L',
'gc=l&' => 'Gc/LC',
'gc=l_' => 'Gc/LC',
'gc=lc' => 'Gc/LC',
'gc=letter' => 'Gc/L',
'gc=letternumber' => 'Gc/Nl',
'gc=lineseparator' => '#/346',
'gc=ll' => 'Gc/Ll',
'gc=lm' => 'Gc/Lm',
'gc=lo' => 'Gc/Lo',
'gc=lowercaseletter' => 'Gc/Ll',
'gc=lt' => 'Perl/Title',
'gc=lu' => 'Gc/Lu',
'gc=m' => 'Gc/M',
'gc=mark' => 'Gc/M',
'gc=mathsymbol' => 'Gc/Sm',
'gc=mc' => 'Gc/Mc',
'gc=me' => 'Gc/Me',
'gc=mn' => 'Gc/Mn',
'gc=modifierletter' => 'Gc/Lm',
'gc=modifiersymbol' => 'Gc/Sk',
'gc=n' => 'Gc/N',
'gc=nd' => 'Gc/Nd',
'gc=nl' => 'Gc/Nl',
'gc=no' => 'Gc/No',
'gc=nonspacingmark' => 'Gc/Mn',
'gc=number' => 'Gc/N',
'gc=openpunctuation' => 'Gc/Ps',
'gc=other' => 'Gc/C',
'gc=otherletter' => 'Gc/Lo',
'gc=othernumber' => 'Gc/No',
'gc=otherpunctuation' => 'Gc/Po',
'gc=othersymbol' => 'Gc/So',
'gc=p' => 'Gc/P',
'gc=paragraphseparator' => '#/347',
'gc=pc' => 'WB/EX',
'gc=pd' => 'Gc/Pd',
'gc=pe' => 'Gc/Pe',
'gc=pf' => 'Gc/Pf',
'gc=pi' => 'Gc/Pi',
'gc=po' => 'Gc/Po',
'gc=privateuse' => '#/344',
'gc=ps' => 'Gc/Ps',
'gc=punct' => 'Gc/P',
'gc=punctuation' => 'Gc/P',
'gc=s' => 'Gc/S',
'gc=sc' => 'Gc/Sc',
'gc=separator' => 'Gc/Z',
'gc=sk' => 'Gc/Sk',
'gc=sm' => 'Gc/Sm',
'gc=so' => 'Gc/So',
'gc=spaceseparator' => 'Gc/Zs',
'gc=spacingmark' => 'Gc/Mc',
'gc=surrogate' => '#/345',
'gc=symbol' => 'Gc/S',
'gc=titlecaseletter' => 'Perl/Title',
'gc=unassigned' => 'Gc/Cn',
'gc=uppercaseletter' => 'Gc/Lu',
'gc=z' => 'Gc/Z',
'gc=zl' => '#/346',
'gc=zp' => '#/347',
'gc=zs' => 'Gc/Zs',
'gcb=cn' => 'GCB/CN',
'gcb=control' => 'GCB/CN',
'gcb=cr' => '#/63',
'gcb=ex' => 'GCB/EX',
'gcb=extend' => 'GCB/EX',
'gcb=l' => '#/60',
'gcb=lf' => '#/64',
'gcb=lv' => 'GCB/LV',
'gcb=lvt' => 'GCB/LVT',
'gcb=other' => 'GCB/XX',
'gcb=pp' => '#/0',
'gcb=prepend' => '#/0',
'gcb=regionalindicator' => '#/65',
'gcb=ri' => '#/65',
'gcb=sm' => 'GCB/SM',
'gcb=spacingmark' => 'GCB/SM',
'gcb=t' => '#/61',
'gcb=v' => '#/62',
'gcb=xx' => 'GCB/XX',
'generalpunctuation' => '#/265',
'geometricshapes' => '#/301',
'geometricshapesext' => '#/324',
'geometricshapesextended' => '#/324',
'geor' => 'Sc/Geor',
'georgian' => 'Sc/Geor',
'georgiansup' => '#/256',
'georgiansupplement' => '#/256',
'glag' => '#/529',
'glagolitic' => '#/529',
'goth' => '#/530',
'gothic' => '#/530',
'gran' => 'Sc/Gran',
'grantha' => 'Sc/Gran',
'graph' => 'Perl/Graph',
'graphemebase' => 'GrBase/Y',
'graphemeextend' => 'GCB/EX',
'grbase' => 'GrBase/Y',
'grbase=f' => '!GrBase/Y',
'grbase=false' => '!GrBase/Y',
'grbase=n' => '!GrBase/Y',
'grbase=no' => '!GrBase/Y',
'grbase=t' => 'GrBase/Y',
'grbase=true' => 'GrBase/Y',
'grbase=y' => 'GrBase/Y',
'grbase=yes' => 'GrBase/Y',
'greek' => 'Sc/Grek',
'greekandcoptic' => '#/110',
'greekext' => '#/190',
'greekextended' => '#/190',
'grek' => 'Sc/Grek',
'grext' => 'GCB/EX',
'grext=f' => '!GCB/EX',
'grext=false' => '!GCB/EX',
'grext=n' => '!GCB/EX',
'grext=no' => '!GCB/EX',
'grext=t' => 'GCB/EX',
'grext=true' => 'GCB/EX',
'grext=y' => 'GCB/EX',
'grext=yes' => 'GCB/EX',
'gujarati' => 'Sc/Gujr',
'gujr' => 'Sc/Gujr',
'gurmukhi' => 'Sc/Guru',
'guru' => 'Sc/Guru',
'halfandfullforms' => '#/312',
'halfmarks' => '#/211',
'halfwidthandfullwidthforms' => '#/312',
'han' => 'Sc/Han',
'hang' => 'Sc/Hang',
'hangul' => 'Sc/Hang',
'hangulcompatibilityjamo' => '#/235',
'hanguljamo' => '#/98',
'hanguljamoextendeda' => '#/194',
'hanguljamoextendedb' => '#/195',
'hangulsyllables' => '#/129',
'hani' => 'Sc/Han',
'hano' => '#/531',
'hanunoo' => '#/531',
'hebr' => 'Sc/Hebr',
'hebrew' => 'Sc/Hebr',
'hex' => 'Hex/Y',
'hex=f' => '!Hex/Y',
'hex=false' => '!Hex/Y',
'hex=n' => '!Hex/Y',
'hex=no' => '!Hex/Y',
'hex=t' => 'Hex/Y',
'hex=true' => 'Hex/Y',
'hex=y' => 'Hex/Y',
'hex=yes' => 'Hex/Y',
'hexdigit' => 'Hex/Y',
'highprivateusesurrogates' => '#/313',
'highpusurrogates' => '#/313',
'highsurrogates' => '#/292',
'hira' => 'Sc/Hira',
'hiragana' => 'Sc/Hira',
'hmng' => 'Sc/Hmng',
'horizspace' => 'Perl/Blank',
'hst=l' => '#/60',
'hst=leadingjamo' => '#/60',
'hst=lv' => 'GCB/LV',
'hst=lvsyllable' => 'GCB/LV',
'hst=lvt' => 'GCB/LVT',
'hst=lvtsyllable' => 'GCB/LVT',
'hst=na' => 'Hst/NA',
'hst=notapplicable' => 'Hst/NA',
'hst=t' => '#/61',
'hst=trailingjamo' => '#/61',
'hst=v' => '#/62',
'hst=voweljamo' => '#/62',
'hyphen' => 'Hyphen/Y',
'hyphen=f' => '!Hyphen/Y',
'hyphen=false' => '!Hyphen/Y',
'hyphen=n' => '!Hyphen/Y',
'hyphen=no' => '!Hyphen/Y',
'hyphen=t' => 'Hyphen/Y',
'hyphen=true' => 'Hyphen/Y',
'hyphen=y' => 'Hyphen/Y',
'hyphen=yes' => 'Hyphen/Y',
'idc' => 'IDC/Y',
'idc=f' => '!IDC/Y',
'idc=false' => '!IDC/Y',
'idc=n' => '!IDC/Y',
'idc=no' => '!IDC/Y',
'idc=t' => 'IDC/Y',
'idc=true' => 'IDC/Y',
'idc=y' => 'IDC/Y',
'idc=yes' => 'IDC/Y',
'idcontinue' => 'IDC/Y',
'ideo' => 'Ideo/Y',
'ideo=f' => '!Ideo/Y',
'ideo=false' => '!Ideo/Y',
'ideo=n' => '!Ideo/Y',
'ideo=no' => '!Ideo/Y',
'ideo=t' => 'Ideo/Y',
'ideo=true' => 'Ideo/Y',
'ideo=y' => 'Ideo/Y',
'ideo=yes' => 'Ideo/Y',
'ideographic' => 'Ideo/Y',
'ideographicdescriptioncharacters' => '#/90',
'ids' => 'IDS/Y',
'ids=f' => '!IDS/Y',
'ids=false' => '!IDS/Y',
'ids=n' => '!IDS/Y',
'ids=no' => '!IDS/Y',
'ids=t' => 'IDS/Y',
'ids=true' => 'IDS/Y',
'ids=y' => 'IDS/Y',
'ids=yes' => 'IDS/Y',
'idsb' => '#/66',
'idsb=f' => '#/!66',
'idsb=false' => '#/!66',
'idsb=n' => '#/!66',
'idsb=no' => '#/!66',
'idsb=t' => '#/66',
'idsb=true' => '#/66',
'idsb=y' => '#/66',
'idsb=yes' => '#/66',
'idsbinaryoperator' => '#/66',
'idst' => '#/67',
'idst=f' => '#/!67',
'idst=false' => '#/!67',
'idst=n' => '#/!67',
'idst=no' => '#/!67',
'idst=t' => '#/67',
'idst=true' => '#/67',
'idst=y' => '#/67',
'idst=yes' => '#/67',
'idstart' => 'IDS/Y',
'idstrinaryoperator' => '#/67',
'imperialaramaic' => '#/512',
'in=unassigned' => 'Age/NA',
'inaegeannumbers' => '#/281',
'inalchemical' => '#/229',
'inalchemicalsymbols' => '#/229',
'inalphabeticpf' => '#/271',
'inalphabeticpresentationforms' => '#/271',
'inancientgreekmusic' => '#/320',
'inancientgreekmusicalnotation' => '#/320',
'inancientgreeknumbers' => '#/327',
'inancientsymbols' => '#/288',
'inarabic' => '#/121',
'inarabicexta' => '#/230',
'inarabicextendeda' => '#/230',
'inarabicmath' => '#/231',
'inarabicmathematicalalphabeticsymbols' => '#/231',
'inarabicpfa' => '#/205',
'inarabicpfb' => '#/206',
'inarabicpresentationformsa' => '#/205',
'inarabicpresentationformsb' => '#/206',
'inarabicsup' => '#/207',
'inarabicsupplement' => '#/207',
'inarmenian' => '#/178',
'inarrows' => '#/122',
'inascii' => '#/106',
'inavestan' => '#/145',
'inbalinese' => '#/179',
'inbamum' => '#/107',
'inbamumsup' => '#/180',
'inbamumsupplement' => '#/180',
'inbasiclatin' => '#/106',
'inbassavah' => '#/181',
'inbatak' => '#/108',
'inbengali' => '#/146',
'inblockelements' => '#/282',
'inbopomofo' => '#/182',
'inbopomofoext' => '#/250',
'inbopomofoextended' => '#/250',
'inboxdrawing' => '#/232',
'inbrahmi' => '#/123',
'inbraille' => '#/147',
'inbraillepatterns' => '#/147',
'inbuginese' => '#/183',
'inbuhid' => '#/109',
'inbyzantinemusic' => '#/289',
'inbyzantinemusicalsymbols' => '#/289',
'incanadiansyllabics' => '#/105',
'incarian' => '#/124',
'incaucasianalbanian' => '#/321',
'inchakma' => '#/125',
'incham' => '#/97',
'incherokee' => '#/184',
'incjk' => '#/89',
'incjkcompat' => '#/208',
'incjkcompatforms' => '#/290',
'incjkcompatibility' => '#/208',
'incjkcompatibilityforms' => '#/290',
'incjkcompatibilityideographs' => '#/328',
'incjkcompatibilityideographssupplement' => '#/336',
'incjkcompatideographs' => '#/328',
'incjkcompatideographssup' => '#/336',
'incjkexta' => '#/148',
'incjkextb' => '#/149',
'incjkextc' => '#/150',
'incjkextd' => '#/151',
'incjkradicalssup' => '#/291',
'incjkradicalssupplement' => '#/291',
'incjkstrokes' => '#/233',
'incjksymbols' => '#/234',
'incjksymbolsandpunctuation' => '#/234',
'incjkunifiedideographs' => '#/89',
'incjkunifiedideographsextensiona' => '#/148',
'incjkunifiedideographsextensionb' => '#/149',
'incjkunifiedideographsextensionc' => '#/150',
'incjkunifiedideographsextensiond' => '#/151',
'incombiningdiacriticalmarks' => '#/274',
'incombiningdiacriticalmarksextended' => '#/299',
'incombiningdiacriticalmarksforsymbols' => '#/337',
'incombiningdiacriticalmarkssupplement' => '#/300',
'incombininghalfmarks' => '#/211',
'incombiningmarksforsymbols' => '#/337',
'incommonindicnumberforms' => '#/314',
'incompatjamo' => '#/235',
'incontrolpictures' => '#/297',
'incoptic' => '#/126',
'incopticepactnumbers' => '#/323',
'incountingrod' => '#/251',
'incountingrodnumerals' => '#/251',
'incuneiform' => '#/209',
'incuneiformnumbers' => '#/309',
'incuneiformnumbersandpunctuation' => '#/309',
'incurrencysymbols' => '#/298',
'incypriotsyllabary' => '#/310',
'incyrillic' => '#/185',
'incyrillicexta' => '#/272',
'incyrillicextb' => '#/273',
'incyrillicextendeda' => '#/272',
'incyrillicextendedb' => '#/273',
'incyrillicsup' => '#/252',
'incyrillicsupplement' => '#/252',
'incyrillicsupplementary' => '#/252',
'indeseret' => '#/152',
'indevanagari' => '#/236',
'indevanagariext' => '#/283',
'indevanagariextended' => '#/283',
'indiacriticals' => '#/274',
'indiacriticalsext' => '#/299',
'indiacriticalsforsymbols' => '#/337',
'indiacriticalssup' => '#/300',
'indicnumberforms' => '#/314',
'indingbats' => '#/186',
'indomino' => '#/127',
'indominotiles' => '#/127',
'induployan' => '#/187',
'inegyptianhieroglyphs' => '#/329',
'inelbasan' => '#/153',
'inemoticons' => '#/210',
'inenclosedalphanum' => '#/311',
'inenclosedalphanumerics' => '#/311',
'inenclosedalphanumericsupplement' => '#/330',
'inenclosedalphanumsup' => '#/330',
'inenclosedcjk' => '#/253',
'inenclosedcjklettersandmonths' => '#/253',
'inenclosedideographicsup' => '#/338',
'inenclosedideographicsupplement' => '#/338',
'inethiopic' => '#/188',
'inethiopicext' => '#/254',
'inethiopicexta' => '#/275',
'inethiopicextended' => '#/254',
'inethiopicextendeda' => '#/275',
'inethiopicsup' => '#/255',
'inethiopicsupplement' => '#/255',
'ingeneralpunctuation' => '#/265',
'ingeometricshapes' => '#/301',
'ingeometricshapesext' => '#/324',
'ingeometricshapesextended' => '#/324',
'ingeorgian' => '#/189',
'ingeorgiansup' => '#/256',
'ingeorgiansupplement' => '#/256',
'inglagolitic' => '#/237',
'ingothic' => '#/128',
'ingrantha' => '#/154',
'ingreek' => '#/110',
'ingreekandcoptic' => '#/110',
'ingreekext' => '#/190',
'ingreekextended' => '#/190',
'ingujarati' => '#/191',
'ingurmukhi' => '#/192',
'inhalfandfullforms' => '#/312',
'inhalfmarks' => '#/211',
'inhalfwidthandfullwidthforms' => '#/312',
'inhangul' => '#/129',
'inhangulcompatibilityjamo' => '#/235',
'inhanguljamo' => '#/98',
'inhanguljamoextendeda' => '#/194',
'inhanguljamoextendedb' => '#/195',
'inhangulsyllables' => '#/129',
'inhanunoo' => '#/155',
'inhebrew' => '#/130',
'inherited' => 'Sc/Zinh',
'inhighprivateusesurrogates' => '#/313',
'inhighpusurrogates' => '#/313',
'inhighsurrogates' => '#/292',
'inhiragana' => '#/193',
'inidc' => '#/90',
'inideographicdescriptioncharacters' => '#/90',
'inimperialaramaic' => '#/302',
'inindicnumberforms' => '#/314',
'ininscriptionalpahlavi' => '#/333',
'ininscriptionalparthian' => '#/334',
'inipaext' => '#/131',
'inipaextensions' => '#/131',
'initialpunctuation' => 'Gc/Pi',
'injamo' => '#/98',
'injamoexta' => '#/194',
'injamoextb' => '#/195',
'injavanese' => '#/196',
'inkaithi' => '#/132',
'inkanasup' => '#/156',
'inkanasupplement' => '#/156',
'inkanbun' => '#/133',
'inkangxi' => '#/134',
'inkangxiradicals' => '#/134',
'inkannada' => '#/157',
'inkatakana' => '#/197',
'inkatakanaext' => '#/257',
'inkatakanaphoneticextensions' => '#/257',
'inkayahli' => '#/158',
'inkharoshthi' => '#/238',
'inkhmer' => '#/111',
'inkhmersymbols' => '#/276',
'inkhojki' => '#/135',
'inkhudawadi' => '#/212',
'inlao' => '#/91',
'inlatin1' => '#/136',
'inlatin1sup' => '#/136',
'inlatin1supplement' => '#/136',
'inlatinexta' => '#/213',
'inlatinextadditional' => '#/325',
'inlatinextb' => '#/214',
'inlatinextc' => '#/215',
'inlatinextd' => '#/216',
'inlatinexte' => '#/217',
'inlatinextendeda' => '#/213',
'inlatinextendedadditional' => '#/325',
'inlatinextendedb' => '#/214',
'inlatinextendedc' => '#/215',
'inlatinextendedd' => '#/216',
'inlatinextendede' => '#/217',
'inlepcha' => '#/137',
'inletterlikesymbols' => '#/322',
'inlimbu' => '#/112',
'inlineara' => '#/159',
'inlinearbideograms' => '#/315',
'inlinearbsyllabary' => '#/316',
'inlisu' => '#/99',
'inlowsurrogates' => '#/284',
'inlycian' => '#/138',
'inlydian' => '#/139',
'inmahajani' => '#/198',
'inmahjong' => '#/160',
'inmahjongtiles' => '#/160',
'inmalayalam' => '#/218',
'inmandaic' => '#/161',
'inmanichaean' => '#/239',
'inmathalphanum' => '#/277',
'inmathematicalalphanumericsymbols' => '#/277',
'inmathematicaloperators' => '#/285',
'inmathoperators' => '#/285',
'inmeeteimayek' => '#/258',
'inmeeteimayekext' => '#/293',
'inmeeteimayekextensions' => '#/293',
'inmendekikakui' => '#/278',
'inmeroiticcursive' => '#/303',
'inmeroitichieroglyphs' => '#/331',
'inmiao' => '#/100',
'inmiscarrows' => '#/240',
'inmiscellaneousmathematicalsymbolsa' => '#/317',
'inmiscellaneousmathematicalsymbolsb' => '#/318',
'inmiscellaneoussymbols' => '#/259',
'inmiscellaneoussymbolsandarrows' => '#/240',
'inmiscellaneoussymbolsandpictographs' => '#/304',
'inmiscellaneoustechnical' => '#/286',
'inmiscmathsymbolsa' => '#/317',
'inmiscmathsymbolsb' => '#/318',
'inmiscpictographs' => '#/304',
'inmiscsymbols' => '#/259',
'inmisctechnical' => '#/286',
'inmodi' => '#/101',
'inmodifierletters' => '#/305',
'inmodifiertoneletters' => '#/332',
'inmongolian' => '#/219',
'inmro' => '#/92',
'inmusic' => '#/113',
'inmusicalsymbols' => '#/113',
'inmyanmar' => '#/162',
'inmyanmarexta' => '#/260',
'inmyanmarextb' => '#/261',
'inmyanmarextendeda' => '#/260',
'inmyanmarextendedb' => '#/261',
'innabataean' => '#/220',
'innb' => 'Blk/NB',
'innewtailue' => '#/221',
'innko' => '#/93',
'innoblock' => 'Blk/NB',
'innumberforms' => '#/262',
'inocr' => '#/94',
'inogham' => '#/114',
'inolchiki' => '#/163',
'inolditalic' => '#/222',
'inoldnortharabian' => '#/306',
'inoldpermic' => '#/223',
'inoldpersian' => '#/241',
'inoldsoutharabian' => '#/307',
'inoldturkic' => '#/224',
'inopticalcharacterrecognition' => '#/94',
'inoriya' => '#/115',
'inornamentaldingbats' => '#/326',
'inosmanya' => '#/164',
'inpahawhhmong' => '#/263',
'inpalmyrene' => '#/225',
'inpaucinhau' => '#/226',
'inphagspa' => '#/165',
'inphaistos' => '#/199',
'inphaistosdisc' => '#/199',
'inphoenician' => '#/242',
'inphoneticext' => '#/264',
'inphoneticextensions' => '#/264',
'inphoneticextensionssupplement' => '#/294',
'inphoneticextsup' => '#/294',
'inplayingcards' => '#/279',
'inprivateuse' => '#/95',
'inprivateusearea' => '#/95',
'inpsalterpahlavi' => '#/295',
'inpua' => '#/95',
'inpunctuation' => '#/265',
'inrejang' => '#/140',
'inrumi' => '#/102',
'inruminumeralsymbols' => '#/102',
'inrunic' => '#/116',
'insamaritan' => '#/227',
'insaurashtra' => '#/243',
'inscriptionalpahlavi' => '#/557',
'inscriptionalparthian' => '#/560',
'insharada' => '#/166',
'inshavian' => '#/167',
'inshorthandformatcontrols' => '#/339',
'insiddham' => '#/168',
'insinhala' => '#/169',
'insinhalaarchaicnumbers' => '#/335',
'insmallforms' => '#/244',
'insmallformvariants' => '#/244',
'insorasompeng' => '#/266',
'inspacingmodifierletters' => '#/305',
'inspecials' => '#/200',
'insundanese' => '#/228',
'insundanesesup' => '#/280',
'insundanesesupplement' => '#/280',
'insuparrowsa' => '#/245',
'insuparrowsb' => '#/246',
'insuparrowsc' => '#/247',
'insuperandsub' => '#/267',
'insuperscriptsandsubscripts' => '#/267',
'insupmathoperators' => '#/319',
'insupplementalarrowsa' => '#/245',
'insupplementalarrowsb' => '#/246',
'insupplementalarrowsc' => '#/247',
'insupplementalmathematicaloperators' => '#/319',
'insupplementalpunctuation' => '#/296',
'insupplementaryprivateuseareaa' => '#/170',
'insupplementaryprivateuseareab' => '#/171',
'insuppuaa' => '#/170',
'insuppuab' => '#/171',
'insuppunctuation' => '#/296',
'insylotinagri' => '#/268',
'insyriac' => '#/141',
'intagalog' => '#/172',
'intagbanwa' => '#/201',
'intags' => '#/103',
'intaile' => '#/117',
'intaitham' => '#/173',
'intaiviet' => '#/174',
'intaixuanjing' => '#/269',
'intaixuanjingsymbols' => '#/269',
'intakri' => '#/118',
'intamil' => '#/119',
'intelugu' => '#/142',
'inthaana' => '#/143',
'inthai' => '#/104',
'intibetan' => '#/175',
'intifinagh' => '#/202',
'intirhuta' => '#/176',
'intransportandmap' => '#/308',
'intransportandmapsymbols' => '#/308',
'inucas' => '#/105',
'inucasext' => '#/177',
'inugaritic' => '#/203',
'inunifiedcanadianaboriginalsyllabics' => '#/105',
'inunifiedcanadianaboriginalsyllabicsextended' => '#/177',
'invai' => '#/96',
'invariationselectors' => '#/88',
'invariationselectorssupplement' => '#/120',
'invedicext' => '#/204',
'invedicextensions' => '#/204',
'inverticalforms' => '#/287',
'invs' => '#/88',
'invssup' => '#/120',
'inwarangciti' => '#/248',
'inyijing' => '#/144',
'inyijinghexagramsymbols' => '#/144',
'inyiradicals' => '#/249',
'inyisyllables' => '#/270',
'ipaext' => '#/131',
'ipaextensions' => '#/131',
'isaegeannumbers' => '#/281',
'isaghb' => '#/511',
'isahex' => '#/59',
'isalchemical' => '#/229',
'isalchemicalsymbols' => '#/229',
'isall' => '#/1',
'isalnum' => 'Perl/Alnum',
'isalpha' => 'Alpha/Y',
'isalphabetic' => 'Alpha/Y',
'isalphabeticpf' => '#/271',
'isalphabeticpresentationforms' => '#/271',
'isancientgreekmusic' => '#/320',
'isancientgreekmusicalnotation' => '#/320',
'isancientgreeknumbers' => '#/327',
'isancientsymbols' => '#/288',
'isany' => '#/2',
'isarab' => 'Sc/Arab',
'isarabic' => 'Sc/Arab',
'isarabicexta' => '#/230',
'isarabicextendeda' => '#/230',
'isarabicmath' => '#/231',
'isarabicmathematicalalphabeticsymbols' => '#/231',
'isarabicpfa' => '#/205',
'isarabicpfb' => '#/206',
'isarabicpresentationformsa' => '#/205',
'isarabicpresentationformsb' => '#/206',
'isarabicsup' => '#/207',
'isarabicsupplement' => '#/207',
'isarmenian' => 'Sc/Armn',
'isarmi' => '#/512',
'isarmn' => 'Sc/Armn',
'isarrows' => '#/122',
'isascii' => '#/106',
'isasciihexdigit' => '#/59',
'isassigned' => 'Perl/Assigned',
'isavestan' => '#/513',
'isavst' => '#/513',
'isbali' => '#/514',
'isbalinese' => '#/514',
'isbamu' => '#/515',
'isbamum' => '#/515',
'isbamumsup' => '#/180',
'isbamumsupplement' => '#/180',
'isbasiclatin' => '#/106',
'isbass' => '#/516',
'isbassavah' => '#/516',
'isbatak' => '#/517',
'isbatk' => '#/517',
'isbeng' => 'Sc/Beng',
'isbengali' => 'Sc/Beng',
'isbidic' => 'BidiC/Y',
'isbidicontrol' => 'BidiC/Y',
'isbidim' => 'BidiM/Y',
'isbidimirrored' => 'BidiM/Y',
'isblank' => 'Perl/Blank',
'isblockelements' => '#/282',
'isbopo' => '#/518',
'isbopomofo' => '#/518',
'isbopomofoext' => '#/250',
'isbopomofoextended' => '#/250',
'isboxdrawing' => '#/232',
'isbrah' => '#/519',
'isbrahmi' => '#/519',
'isbrai' => '#/147',
'isbraille' => '#/147',
'isbraillepatterns' => '#/147',
'isbugi' => '#/520',
'isbuginese' => '#/520',
'isbuhd' => '#/521',
'isbuhid' => '#/521',
'isbyzantinemusic' => '#/289',
'isbyzantinemusicalsymbols' => '#/289',
'isc' => 'Gc/C',
'iscakm' => '#/522',
'iscanadianaboriginal' => '#/523',
'iscanadiansyllabics' => '#/105',
'iscans' => '#/523',
'iscari' => '#/524',
'iscarian' => '#/524',
'iscased' => 'Cased/Y',
'iscasedletter' => 'Gc/LC',
'iscaseignorable' => 'CI/Y',
'iscaucasianalbanian' => '#/511',
'iscc' => '#/343',
'isce' => 'CE/Y',
'iscf' => 'Gc/Cf',
'ischakma' => '#/522',
'ischam' => 'Sc/Cham',
'ischangeswhencasefolded' => 'CWCF/Y',
'ischangeswhencasemapped' => 'CWCM/Y',
'ischangeswhenlowercased' => 'CWL/Y',
'ischangeswhennfkccasefolded' => 'CWKCF/Y',
'ischangeswhentitlecased' => 'CWT/Y',
'ischangeswhenuppercased' => 'CWU/Y',
'ischer' => '#/525',
'ischerokee' => '#/525',
'isci' => 'CI/Y',
'iscjk' => '#/89',
'iscjkcompat' => '#/208',
'iscjkcompatforms' => '#/290',
'iscjkcompatibility' => '#/208',
'iscjkcompatibilityforms' => '#/290',
'iscjkcompatibilityideographs' => '#/328',
'iscjkcompatibilityideographssupplement' => '#/336',
'iscjkcompatideographs' => '#/328',
'iscjkcompatideographssup' => '#/336',
'iscjkexta' => '#/148',
'iscjkextb' => '#/149',
'iscjkextc' => '#/150',
'iscjkextd' => '#/151',
'iscjkradicalssup' => '#/291',
'iscjkradicalssupplement' => '#/291',
'iscjkstrokes' => '#/233',
'iscjksymbols' => '#/234',
'iscjksymbolsandpunctuation' => '#/234',
'iscjkunifiedideographs' => '#/89',
'iscjkunifiedideographsextensiona' => '#/148',
'iscjkunifiedideographsextensionb' => '#/149',
'iscjkunifiedideographsextensionc' => '#/150',
'iscjkunifiedideographsextensiond' => '#/151',
'isclosepunctuation' => 'Gc/Pe',
'iscn' => 'Gc/Cn',
'iscntrl' => '#/343',
'isco' => '#/344',
'iscombiningdiacriticalmarks' => '#/274',
'iscombiningdiacriticalmarksextended' => '#/299',
'iscombiningdiacriticalmarksforsymbols' => '#/337',
'iscombiningdiacriticalmarkssupplement' => '#/300',
'iscombininghalfmarks' => '#/211',
'iscombiningmark' => 'Gc/M',
'iscombiningmarksforsymbols' => '#/337',
'iscommon' => 'Sc/Zyyy',
'iscommonindicnumberforms' => '#/314',
'iscompatjamo' => '#/235',
'iscompex' => 'CompEx/Y',
'iscompositionexclusion' => 'CE/Y',
'isconnectorpunctuation' => 'WB/EX',
'iscontrol' => '#/343',
'iscontrolpictures' => '#/297',
'iscopt' => '#/526',
'iscoptic' => '#/526',
'iscopticepactnumbers' => '#/323',
'iscountingrod' => '#/251',
'iscountingrodnumerals' => '#/251',
'iscprt' => 'Sc/Cprt',
'iscs' => '#/345',
'iscuneiform' => '#/584',
'iscuneiformnumbers' => '#/309',
'iscuneiformnumbersandpunctuation' => '#/309',
'iscurrencysymbol' => 'Gc/Sc',
'iscurrencysymbols' => '#/298',
'iscwcf' => 'CWCF/Y',
'iscwcm' => 'CWCM/Y',
'iscwkcf' => 'CWKCF/Y',
'iscwl' => 'CWL/Y',
'iscwt' => 'CWT/Y',
'iscwu' => 'CWU/Y',
'iscypriot' => 'Sc/Cprt',
'iscypriotsyllabary' => '#/310',
'iscyrillic' => 'Sc/Cyrl',
'iscyrillicexta' => '#/272',
'iscyrillicextb' => '#/273',
'iscyrillicextendeda' => '#/272',
'iscyrillicextendedb' => '#/273',
'iscyrillicsup' => '#/252',
'iscyrillicsupplement' => '#/252',
'iscyrillicsupplementary' => '#/252',
'iscyrl' => 'Sc/Cyrl',
'isdash' => 'Dash/Y',
'isdashpunctuation' => 'Gc/Pd',
'isdecimalnumber' => 'Gc/Nd',
'isdefaultignorablecodepoint' => 'DI/Y',
'isdep' => 'Dep/Y',
'isdeprecated' => 'Dep/Y',
'isdeseret' => '#/152',
'isdeva' => 'Sc/Deva',
'isdevanagari' => 'Sc/Deva',
'isdevanagariext' => '#/283',
'isdevanagariextended' => '#/283',
'isdi' => 'DI/Y',
'isdia' => 'Dia/Y',
'isdiacritic' => 'Dia/Y',
'isdiacriticals' => '#/274',
'isdiacriticalsext' => '#/299',
'isdiacriticalsforsymbols' => '#/337',
'isdiacriticalssup' => '#/300',
'isdigit' => 'Gc/Nd',
'isdingbats' => '#/186',
'isdomino' => '#/127',
'isdominotiles' => '#/127',
'isdsrt' => '#/152',
'isdupl' => 'Sc/Dupl',
'isduployan' => 'Sc/Dupl',
'isegyp' => '#/527',
'isegyptianhieroglyphs' => '#/527',
'iselba' => '#/528',
'iselbasan' => '#/528',
'isemoticons' => '#/210',
'isenclosedalphanum' => '#/311',
'isenclosedalphanumerics' => '#/311',
'isenclosedalphanumericsupplement' => '#/330',
'isenclosedalphanumsup' => '#/330',
'isenclosedcjk' => '#/253',
'isenclosedcjklettersandmonths' => '#/253',
'isenclosedideographicsup' => '#/338',
'isenclosedideographicsupplement' => '#/338',
'isenclosingmark' => 'Gc/Me',
'isethi' => 'Sc/Ethi',
'isethiopic' => 'Sc/Ethi',
'isethiopicext' => '#/254',
'isethiopicexta' => '#/275',
'isethiopicextended' => '#/254',
'isethiopicextendeda' => '#/275',
'isethiopicsup' => '#/255',
'isethiopicsupplement' => '#/255',
'isext' => 'Ext/Y',
'isextender' => 'Ext/Y',
'isfinalpunctuation' => 'Gc/Pf',
'isformat' => 'Gc/Cf',
'isfullcompositionexclusion' => 'CompEx/Y',
'isgeneralpunctuation' => '#/265',
'isgeometricshapes' => '#/301',
'isgeometricshapesext' => '#/324',
'isgeometricshapesextended' => '#/324',
'isgeor' => 'Sc/Geor',
'isgeorgian' => 'Sc/Geor',
'isgeorgiansup' => '#/256',
'isgeorgiansupplement' => '#/256',
'isglag' => '#/529',
'isglagolitic' => '#/529',
'isgoth' => '#/530',
'isgothic' => '#/530',
'isgran' => 'Sc/Gran',
'isgrantha' => 'Sc/Gran',
'isgraph' => 'Perl/Graph',
'isgraphemebase' => 'GrBase/Y',
'isgraphemeextend' => 'GCB/EX',
'isgrbase' => 'GrBase/Y',
'isgreek' => 'Sc/Grek',
'isgreekandcoptic' => '#/110',
'isgreekext' => '#/190',
'isgreekextended' => '#/190',
'isgrek' => 'Sc/Grek',
'isgrext' => 'GCB/EX',
'isgujarati' => 'Sc/Gujr',
'isgujr' => 'Sc/Gujr',
'isgurmukhi' => 'Sc/Guru',
'isguru' => 'Sc/Guru',
'ishalfandfullforms' => '#/312',
'ishalfmarks' => '#/211',
'ishalfwidthandfullwidthforms' => '#/312',
'ishan' => 'Sc/Han',
'ishang' => 'Sc/Hang',
'ishangul' => 'Sc/Hang',
'ishangulcompatibilityjamo' => '#/235',
'ishanguljamo' => '#/98',
'ishanguljamoextendeda' => '#/194',
'ishanguljamoextendedb' => '#/195',
'ishangulsyllables' => '#/129',
'ishani' => 'Sc/Han',
'ishano' => '#/531',
'ishanunoo' => '#/531',
'ishebr' => 'Sc/Hebr',
'ishebrew' => 'Sc/Hebr',
'ishex' => 'Hex/Y',
'ishexdigit' => 'Hex/Y',
'ishighprivateusesurrogates' => '#/313',
'ishighpusurrogates' => '#/313',
'ishighsurrogates' => '#/292',
'ishira' => 'Sc/Hira',
'ishiragana' => 'Sc/Hira',
'ishmng' => 'Sc/Hmng',
'ishorizspace' => 'Perl/Blank',
'ishyphen' => 'Hyphen/Y',
'isidc' => 'IDC/Y',
'isidcontinue' => 'IDC/Y',
'isideo' => 'Ideo/Y',
'isideographic' => 'Ideo/Y',
'isideographicdescriptioncharacters' => '#/90',
'isids' => 'IDS/Y',
'isidsb' => '#/66',
'isidsbinaryoperator' => '#/66',
'isidst' => '#/67',
'isidstart' => 'IDS/Y',
'isidstrinaryoperator' => '#/67',
'isimperialaramaic' => '#/512',
'isindicnumberforms' => '#/314',
'isinherited' => 'Sc/Zinh',
'isinitialpunctuation' => 'Gc/Pi',
'isinscriptionalpahlavi' => '#/557',
'isinscriptionalparthian' => '#/560',
'isipaext' => '#/131',
'isipaextensions' => '#/131',
'isital' => '#/532',
'isjamo' => '#/98',
'isjamoexta' => '#/194',
'isjamoextb' => '#/195',
'isjava' => '#/533',
'isjavanese' => '#/533',
'isjoinc' => '#/68',
'isjoincontrol' => '#/68',
'iskaithi' => '#/536',
'iskali' => '#/534',
'iskana' => 'Sc/Kana',
'iskanasup' => '#/156',
'iskanasupplement' => '#/156',
'iskanbun' => '#/133',
'iskangxi' => '#/134',
'iskangxiradicals' => '#/134',
'iskannada' => 'Sc/Knda',
'iskatakana' => 'Sc/Kana',
'iskatakanaext' => '#/257',
'iskatakanaphoneticextensions' => '#/257',
'iskayahli' => '#/534',
'iskhar' => 'Sc/Khar',
'iskharoshthi' => 'Sc/Khar',
'iskhmer' => 'Sc/Khmr',
'iskhmersymbols' => '#/276',
'iskhmr' => 'Sc/Khmr',
'iskhoj' => '#/535',
'iskhojki' => '#/535',
'iskhudawadi' => '#/567',
'isknda' => 'Sc/Knda',
'iskthi' => '#/536',
'isl' => 'Gc/L',
'isl&' => 'Gc/LC',
'isl_' => 'Gc/LC',
'islana' => 'Sc/Lana',
'islao' => 'Sc/Lao',
'islaoo' => 'Sc/Lao',
'islatin' => 'Sc/Latn',
'islatin1' => '#/136',
'islatin1sup' => '#/136',
'islatin1supplement' => '#/136',
'islatinexta' => '#/213',
'islatinextadditional' => '#/325',
'islatinextb' => '#/214',
'islatinextc' => '#/215',
'islatinextd' => '#/216',
'islatinexte' => '#/217',
'islatinextendeda' => '#/213',
'islatinextendedadditional' => '#/325',
'islatinextendedb' => '#/214',
'islatinextendedc' => '#/215',
'islatinextendedd' => '#/216',
'islatinextendede' => '#/217',
'islatn' => 'Sc/Latn',
'islc' => 'Gc/LC',
'islepc' => '#/537',
'islepcha' => '#/537',
'isletter' => 'Gc/L',
'isletterlikesymbols' => '#/322',
'isletternumber' => 'Gc/Nl',
'islimb' => 'Sc/Limb',
'islimbu' => 'Sc/Limb',
'islina' => '#/538',
'islinb' => 'Sc/Linb',
'islineara' => '#/538',
'islinearb' => 'Sc/Linb',
'islinearbideograms' => '#/315',
'islinearbsyllabary' => '#/316',
'islineseparator' => '#/346',
'islisu' => '#/99',
'isll' => 'Gc/Ll',
'islm' => 'Gc/Lm',
'islo' => 'Gc/Lo',
'isloe' => 'LOE/Y',
'islogicalorderexception' => 'LOE/Y',
'islower' => 'Lower/Y',
'islowercase' => 'Lower/Y',
'islowercaseletter' => 'Gc/Ll',
'islowsurrogates' => '#/284',
'islt' => 'Perl/Title',
'islu' => 'Gc/Lu',
'islyci' => '#/539',
'islycian' => '#/539',
'islydi' => '#/540',
'islydian' => '#/540',
'ism' => 'Gc/M',
'ismahajani' => '#/541',
'ismahj' => '#/541',
'ismahjong' => '#/160',
'ismahjongtiles' => '#/160',
'ismalayalam' => 'Sc/Mlym',
'ismand' => '#/542',
'ismandaic' => '#/542',
'ismani' => '#/543',
'ismanichaean' => '#/543',
'ismark' => 'Gc/M',
'ismath' => 'Math/Y',
'ismathalphanum' => '#/277',
'ismathematicalalphanumericsymbols' => '#/277',
'ismathematicaloperators' => '#/285',
'ismathoperators' => '#/285',
'ismathsymbol' => 'Gc/Sm',
'ismc' => 'Gc/Mc',
'isme' => 'Gc/Me',
'ismeeteimayek' => '#/548',
'ismeeteimayekext' => '#/293',
'ismeeteimayekextensions' => '#/293',
'ismend' => '#/544',
'ismendekikakui' => '#/544',
'ismerc' => '#/545',
'ismero' => '#/331',
'ismeroiticcursive' => '#/545',
'ismeroitichieroglyphs' => '#/331',
'ismiao' => '#/546',
'ismiscarrows' => '#/240',
'ismiscellaneousmathematicalsymbolsa' => '#/317',
'ismiscellaneousmathematicalsymbolsb' => '#/318',
'ismiscellaneoussymbols' => '#/259',
'ismiscellaneoussymbolsandarrows' => '#/240',
'ismiscellaneoussymbolsandpictographs' => '#/304',
'ismiscellaneoustechnical' => '#/286',
'ismiscmathsymbolsa' => '#/317',
'ismiscmathsymbolsb' => '#/318',
'ismiscpictographs' => '#/304',
'ismiscsymbols' => '#/259',
'ismisctechnical' => '#/286',
'ismlym' => 'Sc/Mlym',
'ismn' => 'Gc/Mn',
'ismodi' => '#/547',
'ismodifierletter' => 'Gc/Lm',
'ismodifierletters' => '#/305',
'ismodifiersymbol' => 'Gc/Sk',
'ismodifiertoneletters' => '#/332',
'ismong' => 'Sc/Mong',
'ismongolian' => 'Sc/Mong',
'ismro' => '#/508',
'ismroo' => '#/508',
'ismtei' => '#/548',
'ismusic' => '#/113',
'ismusicalsymbols' => '#/113',
'ismyanmar' => '#/549',
'ismyanmarexta' => '#/260',
'ismyanmarextb' => '#/261',
'ismyanmarextendeda' => '#/260',
'ismyanmarextendedb' => '#/261',
'ismymr' => '#/549',
'isn' => 'Gc/N',
'isnabataean' => '#/550',
'isnarb' => '#/306',
'isnb' => 'Blk/NB',
'isnbat' => '#/550',
'isnchar' => 'NChar/Y',
'isnd' => 'Gc/Nd',
'isnewtailue' => 'Sc/Talu',
'isnko' => '#/509',
'isnkoo' => '#/509',
'isnl' => 'Gc/Nl',
'isno' => 'Gc/No',
'isnoblock' => 'Blk/NB',
'isnoncharactercodepoint' => 'NChar/Y',
'isnonspacingmark' => 'Gc/Mn',
'isnumber' => 'Gc/N',
'isnumberforms' => '#/262',
'isocr' => '#/94',
'isogam' => '#/551',
'isogham' => '#/551',
'isolchiki' => '#/163',
'isolck' => '#/163',
'isolditalic' => '#/532',
'isoldnortharabian' => '#/306',
'isoldpermic' => '#/555',
'isoldpersian' => '#/583',
'isoldsoutharabian' => '#/307',
'isoldturkic' => '#/552',
'isopenpunctuation' => 'Gc/Ps',
'isopticalcharacterrecognition' => '#/94',
'isoriya' => 'Sc/Orya',
'isorkh' => '#/552',
'isornamentaldingbats' => '#/326',
'isorya' => 'Sc/Orya',
'isosma' => '#/553',
'isosmanya' => '#/553',
'isother' => 'Gc/C',
'isotherletter' => 'Gc/Lo',
'isothernumber' => 'Gc/No',
'isotherpunctuation' => 'Gc/Po',
'isothersymbol' => 'Gc/So',
'isp' => 'Gc/P',
'ispahawhhmong' => 'Sc/Hmng',
'ispalm' => '#/225',
'ispalmyrene' => '#/225',
'isparagraphseparator' => '#/347',
'ispatsyn' => 'PatSyn/Y',
'ispatternsyntax' => 'PatSyn/Y',
'ispatternwhitespace' => 'PatWS/Y',
'ispatws' => 'PatWS/Y',
'ispauc' => '#/554',
'ispaucinhau' => '#/554',
'ispc' => 'WB/EX',
'ispd' => 'Gc/Pd',
'ispe' => 'Gc/Pe',
'isperlspace' => '#/3',
'isperlword' => 'Perl/PerlWord',
'isperm' => '#/555',
'ispf' => 'Gc/Pf',
'isphag' => '#/556',
'isphagspa' => '#/556',
'isphaistos' => '#/199',
'isphaistosdisc' => '#/199',
'isphli' => '#/557',
'isphlp' => '#/558',
'isphnx' => '#/559',
'isphoenician' => '#/559',
'isphoneticext' => '#/264',
'isphoneticextensions' => '#/264',
'isphoneticextensionssupplement' => '#/294',
'isphoneticextsup' => '#/294',
'ispi' => 'Gc/Pi',
'isplayingcards' => '#/279',
'isplrd' => '#/546',
'ispo' => 'Gc/Po',
'isposixalnum' => '#/5',
'isposixalpha' => '#/6',
'isposixblank' => '#/7',
'isposixcntrl' => '#/8',
'isposixdigit' => '#/9',
'isposixgraph' => '#/10',
'isposixlower' => '#/11',
'isposixprint' => '#/12',
'isposixpunct' => 'Perl/PosixPun',
'isposixspace' => '#/3',
'isposixupper' => '#/13',
'isposixword' => 'Perl/PerlWord',
'isposixxdigit' => '#/59',
'isprint' => 'Perl/Print',
'isprivateuse' => '#/344',
'isprivateusearea' => '#/95',
'isprti' => '#/560',
'isps' => 'Gc/Ps',
'ispsalterpahlavi' => '#/558',
'ispua' => '#/95',
'ispunct' => 'Gc/P',
'ispunctuation' => 'Gc/P',
'isqaac' => '#/526',
'isqaai' => 'Sc/Zinh',
'isqmark' => 'QMark/Y',
'isquotationmark' => 'QMark/Y',
'isradical' => '#/69',
'isrejang' => '#/561',
'isrjng' => '#/561',
'isrumi' => '#/102',
'isruminumeralsymbols' => '#/102',
'isrunic' => '#/562',
'isrunr' => '#/562',
'iss' => 'Gc/S',
'issamaritan' => '#/563',
'issamr' => '#/563',
'issarb' => '#/307',
'issaur' => '#/564',
'issaurashtra' => '#/564',
'issc' => 'Gc/Sc',
'issd' => 'SD/Y',
'isseparator' => 'Gc/Z',
'issharada' => '#/565',
'isshavian' => '#/167',
'isshaw' => '#/167',
'isshorthandformatcontrols' => '#/339',
'isshrd' => '#/565',
'issidd' => '#/566',
'issiddham' => '#/566',
'issind' => '#/567',
'issinh' => 'Sc/Sinh',
'issinhala' => 'Sc/Sinh',
'issinhalaarchaicnumbers' => '#/335',
'issk' => 'Gc/Sk',
'issm' => 'Gc/Sm',
'issmallforms' => '#/244',
'issmallformvariants' => '#/244',
'isso' => 'Gc/So',
'issoftdotted' => 'SD/Y',
'issora' => '#/568',
'issorasompeng' => '#/568',
'isspace' => 'Perl/SpacePer',
'isspaceperl' => 'Perl/SpacePer',
'isspaceseparator' => 'Gc/Zs',
'isspacingmark' => 'Gc/Mc',
'isspacingmodifierletters' => '#/305',
'isspecials' => '#/200',
'issterm' => 'STerm/Y',
'issund' => '#/569',
'issundanese' => '#/569',
'issundanesesup' => '#/280',
'issundanesesupplement' => '#/280',
'issuparrowsa' => '#/245',
'issuparrowsb' => '#/246',
'issuparrowsc' => '#/247',
'issuperandsub' => '#/267',
'issuperscriptsandsubscripts' => '#/267',
'issupmathoperators' => '#/319',
'issupplementalarrowsa' => '#/245',
'issupplementalarrowsb' => '#/246',
'issupplementalarrowsc' => '#/247',
'issupplementalmathematicaloperators' => '#/319',
'issupplementalpunctuation' => '#/296',
'issupplementaryprivateuseareaa' => '#/170',
'issupplementaryprivateuseareab' => '#/171',
'issuppuaa' => '#/170',
'issuppuab' => '#/171',
'issuppunctuation' => '#/296',
'issurrogate' => '#/345',
'issylo' => '#/570',
'issylotinagri' => '#/570',
'issymbol' => 'Gc/S',
'issyrc' => '#/571',
'issyriac' => '#/571',
'istagalog' => '#/577',
'istagb' => '#/572',
'istagbanwa' => '#/572',
'istags' => '#/103',
'istaile' => '#/574',
'istaitham' => 'Sc/Lana',
'istaiviet' => '#/575',
'istaixuanjing' => '#/269',
'istaixuanjingsymbols' => '#/269',
'istakr' => '#/573',
'istakri' => '#/573',
'istale' => '#/574',
'istalu' => 'Sc/Talu',
'istamil' => 'Sc/Taml',
'istaml' => 'Sc/Taml',
'istavt' => '#/575',
'istelu' => 'Sc/Telu',
'istelugu' => 'Sc/Telu',
'isterm' => 'Term/Y',
'isterminalpunctuation' => 'Term/Y',
'istfng' => '#/576',
'istglg' => '#/577',
'isthaa' => '#/578',
'isthaana' => '#/578',
'isthai' => '#/579',
'istibetan' => 'Sc/Tibt',
'istibt' => 'Sc/Tibt',
'istifinagh' => '#/576',
'istirh' => '#/580',
'istirhuta' => '#/580',
'istitle' => 'Perl/Title',
'istitlecase' => 'Perl/Title',
'istitlecaseletter' => 'Perl/Title',
'istransportandmap' => '#/308',
'istransportandmapsymbols' => '#/308',
'isucas' => '#/105',
'isucasext' => '#/177',
'isugar' => '#/581',
'isugaritic' => '#/581',
'isuideo' => 'UIdeo/Y',
'isunassigned' => 'Gc/Cn',
'isunicode' => '#/2',
'isunifiedcanadianaboriginalsyllabics' => '#/105',
'isunifiedcanadianaboriginalsyllabicsextended' => '#/177',
'isunifiedideograph' => 'UIdeo/Y',
'isunknown' => 'Sc/Zzzz',
'isupper' => 'Upper/Y',
'isuppercase' => 'Upper/Y',
'isuppercaseletter' => 'Gc/Lu',
'isvai' => '#/510',
'isvaii' => '#/510',
'isvariationselector' => '#/71',
'isvariationselectors' => '#/88',
'isvariationselectorssupplement' => '#/120',
'isvedicext' => '#/204',
'isvedicextensions' => '#/204',
'isverticalforms' => '#/287',
'isvertspace' => '#/4',
'isvs' => '#/71',
'isvssup' => '#/120',
'iswara' => '#/582',
'iswarangciti' => '#/582',
'iswhitespace' => 'Perl/SpacePer',
'isword' => 'Perl/Word',
'iswspace' => 'Perl/SpacePer',
'isxdigit' => 'Hex/Y',
'isxidc' => 'XIDC/Y',
'isxidcontinue' => 'XIDC/Y',
'isxids' => 'XIDS/Y',
'isxidstart' => 'XIDS/Y',
'isxpeo' => '#/583',
'isxperlspace' => 'Perl/SpacePer',
'isxposixalnum' => 'Perl/Alnum',
'isxposixalpha' => 'Alpha/Y',
'isxposixblank' => 'Perl/Blank',
'isxposixcntrl' => '#/343',
'isxposixdigit' => 'Gc/Nd',
'isxposixgraph' => 'Perl/Graph',
'isxposixlower' => 'Lower/Y',
'isxposixprint' => 'Perl/Print',
'isxposixpunct' => 'Perl/XPosixPu',
'isxposixspace' => 'Perl/SpacePer',
'isxposixupper' => 'Upper/Y',
'isxposixword' => 'Perl/Word',
'isxposixxdigit' => 'Hex/Y',
'isxsux' => '#/584',
'isyi' => '#/507',
'isyiii' => '#/507',
'isyijing' => '#/144',
'isyijinghexagramsymbols' => '#/144',
'isyiradicals' => '#/249',
'isyisyllables' => '#/270',
'isz' => 'Gc/Z',
'iszinh' => 'Sc/Zinh',
'iszl' => '#/346',
'iszp' => '#/347',
'iszs' => 'Gc/Zs',
'iszyyy' => 'Sc/Zyyy',
'iszzzz' => 'Sc/Zzzz',
'ital' => '#/532',
'jamo' => '#/98',
'jamoexta' => '#/194',
'jamoextb' => '#/195',
'java' => '#/533',
'javanese' => '#/533',
'jg=ain' => 'Jg/Ain',
'jg=alaph' => '#/369',
'jg=alef' => 'Jg/Alef',
'jg=beh' => 'Jg/Beh',
'jg=beth' => '#/359',
'jg=burushaskiyehbarree' => '#/417',
'jg=dal' => 'Jg/Dal',
'jg=dalathrish' => '#/381',
'jg=e' => '#/348',
'jg=farsiyeh' => 'Jg/FarsiYeh',
'jg=fe' => '#/349',
'jg=feh' => 'Jg/Feh',
'jg=finalsemkath' => '#/388',
'jg=gaf' => 'Jg/Gaf',
'jg=gamal' => '#/370',
'jg=hah' => 'Jg/Hah',
'jg=hamzaonhehgoal' => '#/396',
'jg=he' => '#/350',
'jg=heh' => '#/352',
'jg=hehgoal' => '#/376',
'jg=heth' => '#/360',
'jg=kaf' => '#/353',
'jg=kaph' => '#/361',
'jg=khaph' => '#/371',
'jg=knottedheh' => '#/382',
'jg=lam' => 'Jg/Lam',
'jg=lamadh' => '#/374',
'jg=manichaeanaleph' => '#/406',
'jg=manichaeanayin' => '#/397',
'jg=manichaeanbeth' => '#/398',
'jg=manichaeandaleth' => '#/410',
'jg=manichaeandhamedh' => '#/414',
'jg=manichaeanfive' => '#/399',
'jg=manichaeangimel' => '#/407',
'jg=manichaeanheth' => '#/400',
'jg=manichaeanhundred' => '#/415',
'jg=manichaeankaph' => '#/401',
'jg=manichaeanlamedh' => '#/411',
'jg=manichaeanmem' => '#/390',
'jg=manichaeannun' => '#/391',
'jg=manichaeanone' => '#/392',
'jg=manichaeanpe' => '#/389',
'jg=manichaeanqoph' => '#/402',
'jg=manichaeanresh' => '#/403',
'jg=manichaeansadhe' => '#/408',
'jg=manichaeansamekh' => '#/412',
'jg=manichaeantaw' => '#/393',
'jg=manichaeanten' => '#/394',
'jg=manichaeanteth' => '#/404',
'jg=manichaeanthamedh' => '#/416',
'jg=manichaeantwenty' => '#/413',
'jg=manichaeanwaw' => '#/395',
'jg=manichaeanyodh' => '#/405',
'jg=manichaeanzayin' => '#/409',
'jg=meem' => '#/362',
'jg=mim' => '#/354',
'jg=nojoininggroup' => 'Jg/NoJoinin',
'jg=noon' => '#/363',
'jg=nun' => '#/355',
'jg=nya' => '#/356',
'jg=pe' => '#/351',
'jg=qaf' => 'Jg/Qaf',
'jg=qaph' => '#/364',
'jg=reh' => 'Jg/Reh',
'jg=reversedpe' => '#/383',
'jg=rohingyayeh' => '#/385',
'jg=sad' => 'Jg/Sad',
'jg=sadhe' => '#/372',
'jg=seen' => 'Jg/Seen',
'jg=semkath' => '#/377',
'jg=shin' => '#/365',
'jg=straightwaw' => '#/386',
'jg=swashkaf' => '#/378',
'jg=syriacwaw' => '#/379',
'jg=tah' => '#/357',
'jg=taw' => '#/358',
'jg=tehmarbuta' => '#/384',
'jg=tehmarbutagoal' => '#/396',
'jg=teth' => '#/366',
'jg=waw' => 'Jg/Waw',
'jg=yeh' => 'Jg/Yeh',
'jg=yehbarree' => '#/380',
'jg=yehwithtail' => '#/387',
'jg=yudh' => '#/367',
'jg=yudhhe' => '#/375',
'jg=zain' => '#/368',
'jg=zhain' => '#/373',
'joinc' => '#/68',
'joinc=f' => '#/!68',
'joinc=false' => '#/!68',
'joinc=n' => '#/!68',
'joinc=no' => '#/!68',
'joinc=t' => '#/68',
'joinc=true' => '#/68',
'joinc=y' => '#/68',
'joinc=yes' => '#/68',
'joincontrol' => '#/68',
'jt=c' => 'Jt/C',
'jt=d' => 'Jt/D',
'jt=dualjoining' => 'Jt/D',
'jt=joincausing' => 'Jt/C',
'jt=l' => '#/418',
'jt=leftjoining' => '#/418',
'jt=nonjoining' => 'Jt/U',
'jt=r' => 'Jt/R',
'jt=rightjoining' => 'Jt/R',
'jt=t' => 'Jt/T',
'jt=transparent' => 'Jt/T',
'jt=u' => 'Jt/U',
'kaithi' => '#/536',
'kali' => '#/534',
'kana' => 'Sc/Kana',
'kanasup' => '#/156',
'kanasupplement' => '#/156',
'kanbun' => '#/133',
'kangxi' => '#/134',
'kangxiradicals' => '#/134',
'kannada' => 'Sc/Knda',
'katakana' => 'Sc/Kana',
'katakanaext' => '#/257',
'katakanaphoneticextensions' => '#/257',
'kayahli' => '#/534',
'khar' => 'Sc/Khar',
'kharoshthi' => 'Sc/Khar',
'khmer' => 'Sc/Khmr',
'khmersymbols' => '#/276',
'khmr' => 'Sc/Khmr',
'khoj' => '#/535',
'khojki' => '#/535',
'khudawadi' => '#/567',
'knda' => 'Sc/Knda',
'kthi' => '#/536',
'l' => 'Gc/L',
'l&' => 'Gc/LC',
'l_' => 'Gc/LC',
'lana' => 'Sc/Lana',
'lao' => 'Sc/Lao',
'laoo' => 'Sc/Lao',
'latin' => 'Sc/Latn',
'latin1' => '#/136',
'latin1sup' => '#/136',
'latin1supplement' => '#/136',
'latinexta' => '#/213',
'latinextadditional' => '#/325',
'latinextb' => '#/214',
'latinextc' => '#/215',
'latinextd' => '#/216',
'latinexte' => '#/217',
'latinextendeda' => '#/213',
'latinextendedadditional' => '#/325',
'latinextendedb' => '#/214',
'latinextendedc' => '#/215',
'latinextendedd' => '#/216',
'latinextendede' => '#/217',
'latn' => 'Sc/Latn',
'lb=ai' => 'Lb/AI',
'lb=al' => 'Lb/AL',
'lb=alphabetic' => 'Lb/AL',
'lb=ambiguous' => 'Lb/AI',
'lb=b2' => '#/419',
'lb=ba' => 'Lb/BA',
'lb=bb' => 'Lb/BB',
'lb=bk' => '#/420',
'lb=breakafter' => 'Lb/BA',
'lb=breakbefore' => 'Lb/BB',
'lb=breakboth' => '#/419',
'lb=breaksymbols' => '#/428',
'lb=carriagereturn' => '#/63',
'lb=cb' => '#/421',
'lb=cj' => 'Lb/CJ',
'lb=cl' => 'Lb/CL',
'lb=closeparenthesis' => '#/422',
'lb=closepunctuation' => 'Lb/CL',
'lb=cm' => 'Lb/CM',
'lb=combiningmark' => 'Lb/CM',
'lb=complexcontext' => 'Lb/SA',
'lb=conditionaljapanesestarter' => 'Lb/CJ',
'lb=contingentbreak' => '#/421',
'lb=cp' => '#/422',
'lb=cr' => '#/63',
'lb=ex' => 'Lb/EX',
'lb=exclamation' => 'Lb/EX',
'lb=gl' => 'Lb/GL',
'lb=glue' => 'Lb/GL',
'lb=h2' => 'GCB/LV',
'lb=h3' => 'GCB/LVT',
'lb=hebrewletter' => 'WB/HL',
'lb=hl' => 'WB/HL',
'lb=hy' => '#/423',
'lb=hyphen' => '#/423',
'lb=id' => 'Lb/ID',
'lb=ideographic' => 'Lb/ID',
'lb=in' => '#/424',
'lb=infixnumeric' => 'Lb/IS',
'lb=inseparable' => '#/424',
'lb=inseperable' => '#/424',
'lb=is' => 'Lb/IS',
'lb=jl' => '#/60',
'lb=jt' => '#/61',
'lb=jv' => '#/62',
'lb=lf' => '#/64',
'lb=linefeed' => '#/64',
'lb=mandatorybreak' => '#/420',
'lb=nextline' => '#/425',
'lb=nl' => '#/425',
'lb=nonstarter' => 'Lb/NS',
'lb=ns' => 'Lb/NS',
'lb=nu' => 'SB/NU',
'lb=numeric' => 'SB/NU',
'lb=op' => 'Lb/OP',
'lb=openpunctuation' => 'Lb/OP',
'lb=po' => 'Lb/PO',
'lb=postfixnumeric' => 'Lb/PO',
'lb=pr' => 'Lb/PR',
'lb=prefixnumeric' => 'Lb/PR',
'lb=qu' => 'Lb/QU',
'lb=quotation' => 'Lb/QU',
'lb=regionalindicator' => '#/65',
'lb=ri' => '#/65',
'lb=sa' => 'Lb/SA',
'lb=sg' => '#/426',
'lb=sp' => '#/427',
'lb=space' => '#/427',
'lb=surrogate' => '#/426',
'lb=sy' => '#/428',
'lb=unknown' => 'Lb/XX',
'lb=wj' => '#/429',
'lb=wordjoiner' => '#/429',
'lb=xx' => 'Lb/XX',
'lb=zw' => '#/430',
'lb=zwspace' => '#/430',
'lc' => 'Gc/LC',
'lepc' => '#/537',
'lepcha' => '#/537',
'letter' => 'Gc/L',
'letterlikesymbols' => '#/322',
'letternumber' => 'Gc/Nl',
'limb' => 'Sc/Limb',
'limbu' => 'Sc/Limb',
'lina' => '#/538',
'linb' => 'Sc/Linb',
'lineara' => '#/538',
'linearb' => 'Sc/Linb',
'linearbideograms' => '#/315',
'linearbsyllabary' => '#/316',
'lineseparator' => '#/346',
'lisu' => '#/99',
'll' => 'Gc/Ll',
'lm' => 'Gc/Lm',
'lo' => 'Gc/Lo',
'loe' => 'LOE/Y',
'loe=f' => '!LOE/Y',
'loe=false' => '!LOE/Y',
'loe=n' => '!LOE/Y',
'loe=no' => '!LOE/Y',
'loe=t' => 'LOE/Y',
'loe=true' => 'LOE/Y',
'loe=y' => 'LOE/Y',
'loe=yes' => 'LOE/Y',
'logicalorderexception' => 'LOE/Y',
'lower' => 'Lower/Y',
'lower=f' => '!Lower/Y',
'lower=false' => '!Lower/Y',
'lower=n' => '!Lower/Y',
'lower=no' => '!Lower/Y',
'lower=t' => 'Lower/Y',
'lower=true' => 'Lower/Y',
'lower=y' => 'Lower/Y',
'lower=yes' => 'Lower/Y',
'lowercase' => 'Lower/Y',
'lowercaseletter' => 'Gc/Ll',
'lowsurrogates' => '#/284',
'lt' => 'Perl/Title',
'lu' => 'Gc/Lu',
'lyci' => '#/539',
'lycian' => '#/539',
'lydi' => '#/540',
'lydian' => '#/540',
'm' => 'Gc/M',
'mahajani' => '#/541',
'mahj' => '#/541',
'mahjong' => '#/160',
'mahjongtiles' => '#/160',
'malayalam' => 'Sc/Mlym',
'mand' => '#/542',
'mandaic' => '#/542',
'mani' => '#/543',
'manichaean' => '#/543',
'mark' => 'Gc/M',
'math' => 'Math/Y',
'math=f' => '!Math/Y',
'math=false' => '!Math/Y',
'math=n' => '!Math/Y',
'math=no' => '!Math/Y',
'math=t' => 'Math/Y',
'math=true' => 'Math/Y',
'math=y' => 'Math/Y',
'math=yes' => 'Math/Y',
'mathalphanum' => '#/277',
'mathematicalalphanumericsymbols' => '#/277',
'mathematicaloperators' => '#/285',
'mathoperators' => '#/285',
'mathsymbol' => 'Gc/Sm',
'mc' => 'Gc/Mc',
'me' => 'Gc/Me',
'meeteimayek' => '#/548',
'meeteimayekext' => '#/293',
'meeteimayekextensions' => '#/293',
'mend' => '#/544',
'mendekikakui' => '#/544',
'merc' => '#/545',
'mero' => '#/331',
'meroiticcursive' => '#/545',
'meroitichieroglyphs' => '#/331',
'miao' => '#/546',
'miscarrows' => '#/240',
'miscellaneousmathematicalsymbolsa' => '#/317',
'miscellaneousmathematicalsymbolsb' => '#/318',
'miscellaneoussymbols' => '#/259',
'miscellaneoussymbolsandarrows' => '#/240',
'miscellaneoussymbolsandpictographs' => '#/304',
'miscellaneoustechnical' => '#/286',
'miscmathsymbolsa' => '#/317',
'miscmathsymbolsb' => '#/318',
'miscpictographs' => '#/304',
'miscsymbols' => '#/259',
'misctechnical' => '#/286',
'mlym' => 'Sc/Mlym',
'mn' => 'Gc/Mn',
'modi' => '#/547',
'modifierletter' => 'Gc/Lm',
'modifierletters' => '#/305',
'modifiersymbol' => 'Gc/Sk',
'modifiertoneletters' => '#/332',
'mong' => 'Sc/Mong',
'mongolian' => 'Sc/Mong',
'mro' => '#/508',
'mroo' => '#/508',
'mtei' => '#/548',
'music' => '#/113',
'musicalsymbols' => '#/113',
'myanmar' => '#/549',
'myanmarexta' => '#/260',
'myanmarextb' => '#/261',
'myanmarextendeda' => '#/260',
'myanmarextendedb' => '#/261',
'mymr' => '#/549',
'n' => 'Gc/N',
'nabataean' => '#/550',
'narb' => '#/306',
'nb' => 'Blk/NB',
'nbat' => '#/550',
'nchar' => 'NChar/Y',
'nchar=f' => '!NChar/Y',
'nchar=false' => '!NChar/Y',
'nchar=n' => '!NChar/Y',
'nchar=no' => '!NChar/Y',
'nchar=t' => 'NChar/Y',
'nchar=true' => 'NChar/Y',
'nchar=y' => 'NChar/Y',
'nchar=yes' => 'NChar/Y',
'nd' => 'Gc/Nd',
'newtailue' => 'Sc/Talu',
'nfcqc=m' => 'NFCQC/M',
'nfcqc=maybe' => 'NFCQC/M',
'nfcqc=n' => 'CompEx/Y',
'nfcqc=no' => 'CompEx/Y',
'nfcqc=y' => 'NFCQC/Y',
'nfcqc=yes' => 'NFCQC/Y',
'nfdqc=n' => 'NFDQC/N',
'nfdqc=no' => 'NFDQC/N',
'nfdqc=y' => 'NFDQC/Y',
'nfdqc=yes' => 'NFDQC/Y',
'nfkcqc=m' => 'NFCQC/M',
'nfkcqc=maybe' => 'NFCQC/M',
'nfkcqc=n' => 'NFKCQC/N',
'nfkcqc=no' => 'NFKCQC/N',
'nfkcqc=y' => 'NFKCQC/Y',
'nfkcqc=yes' => 'NFKCQC/Y',
'nfkdqc=n' => 'NFKDQC/N',
'nfkdqc=no' => 'NFKDQC/N',
'nfkdqc=y' => 'NFKDQC/Y',
'nfkdqc=yes' => 'NFKDQC/Y',
'nko' => '#/509',
'nkoo' => '#/509',
'nl' => 'Gc/Nl',
'no' => 'Gc/No',
'noblock' => 'Blk/NB',
'noncharactercodepoint' => 'NChar/Y',
'nonspacingmark' => 'Gc/Mn',
'nt=de' => 'Gc/Nd',
'nt=decimal' => 'Gc/Nd',
'nt=di' => 'Nt/Di',
'nt=digit' => 'Nt/Di',
'nt=none' => 'Nt/None',
'nt=nu' => 'Nt/Nu',
'nt=numeric' => 'Nt/Nu',
'number' => 'Gc/N',
'numberforms' => '#/262',
'nv=nan' => 'Nt/None',
'ocr' => '#/94',
'ogam' => '#/551',
'ogham' => '#/551',
'olchiki' => '#/163',
'olck' => '#/163',
'olditalic' => '#/532',
'oldnortharabian' => '#/306',
'oldpermic' => '#/555',
'oldpersian' => '#/583',
'oldsoutharabian' => '#/307',
'oldturkic' => '#/552',
'openpunctuation' => 'Gc/Ps',
'opticalcharacterrecognition' => '#/94',
'oriya' => 'Sc/Orya',
'orkh' => '#/552',
'ornamentaldingbats' => '#/326',
'orya' => 'Sc/Orya',
'osma' => '#/553',
'osmanya' => '#/553',
'other' => 'Gc/C',
'otherletter' => 'Gc/Lo',
'othernumber' => 'Gc/No',
'otherpunctuation' => 'Gc/Po',
'othersymbol' => 'Gc/So',
'p' => 'Gc/P',
'pahawhhmong' => 'Sc/Hmng',
'palm' => '#/225',
'palmyrene' => '#/225',
'paragraphseparator' => '#/347',
'patsyn' => 'PatSyn/Y',
'patsyn=f' => '!PatSyn/Y',
'patsyn=false' => '!PatSyn/Y',
'patsyn=n' => '!PatSyn/Y',
'patsyn=no' => '!PatSyn/Y',
'patsyn=t' => 'PatSyn/Y',
'patsyn=true' => 'PatSyn/Y',
'patsyn=y' => 'PatSyn/Y',
'patsyn=yes' => 'PatSyn/Y',
'patternsyntax' => 'PatSyn/Y',
'patternwhitespace' => 'PatWS/Y',
'patws' => 'PatWS/Y',
'patws=f' => '!PatWS/Y',
'patws=false' => '!PatWS/Y',
'patws=n' => '!PatWS/Y',
'patws=no' => '!PatWS/Y',
'patws=t' => 'PatWS/Y',
'patws=true' => 'PatWS/Y',
'patws=y' => 'PatWS/Y',
'patws=yes' => 'PatWS/Y',
'pauc' => '#/554',
'paucinhau' => '#/554',
'pc' => 'WB/EX',
'pd' => 'Gc/Pd',
'pe' => 'Gc/Pe',
'perlspace' => '#/3',
'perlword' => 'Perl/PerlWord',
'perm' => '#/555',
'pf' => 'Gc/Pf',
'phag' => '#/556',
'phagspa' => '#/556',
'phaistos' => '#/199',
'phaistosdisc' => '#/199',
'phli' => '#/557',
'phlp' => '#/558',
'phnx' => '#/559',
'phoenician' => '#/559',
'phoneticext' => '#/264',
'phoneticextensions' => '#/264',
'phoneticextensionssupplement' => '#/294',
'phoneticextsup' => '#/294',
'pi' => 'Gc/Pi',
'playingcards' => '#/279',
'plrd' => '#/546',
'po' => 'Gc/Po',
'posixalnum' => '#/5',
'posixalpha' => '#/6',
'posixblank' => '#/7',
'posixcntrl' => '#/8',
'posixdigit' => '#/9',
'posixgraph' => '#/10',
'posixlower' => '#/11',
'posixprint' => '#/12',
'posixpunct' => 'Perl/PosixPun',
'posixspace' => '#/3',
'posixupper' => '#/13',
'posixword' => 'Perl/PerlWord',
'posixxdigit' => '#/59',
'print' => 'Perl/Print',
'privateuse' => '#/344',
'privateusearea' => '#/95',
'prti' => '#/560',
'ps' => 'Gc/Ps',
'psalterpahlavi' => '#/558',
'pua' => '#/95',
'punct' => 'Gc/P',
'punctuation' => 'Gc/P',
'qaac' => '#/526',
'qaai' => 'Sc/Zinh',
'qmark' => 'QMark/Y',
'qmark=f' => '!QMark/Y',
'qmark=false' => '!QMark/Y',
'qmark=n' => '!QMark/Y',
'qmark=no' => '!QMark/Y',
'qmark=t' => 'QMark/Y',
'qmark=true' => 'QMark/Y',
'qmark=y' => 'QMark/Y',
'qmark=yes' => 'QMark/Y',
'quotationmark' => 'QMark/Y',
'radical' => '#/69',
'radical=f' => '#/!69',
'radical=false' => '#/!69',
'radical=n' => '#/!69',
'radical=no' => '#/!69',
'radical=t' => '#/69',
'radical=true' => '#/69',
'radical=y' => '#/69',
'radical=yes' => '#/69',
'rejang' => '#/561',
'rjng' => '#/561',
'rumi' => '#/102',
'ruminumeralsymbols' => '#/102',
'runic' => '#/562',
'runr' => '#/562',
's' => 'Gc/S',
'samaritan' => '#/563',
'samr' => '#/563',
'sarb' => '#/307',
'saur' => '#/564',
'saurashtra' => '#/564',
'sb=at' => 'SB/AT',
'sb=aterm' => 'SB/AT',
'sb=cl' => 'SB/CL',
'sb=close' => 'SB/CL',
'sb=cr' => '#/63',
'sb=ex' => 'SB/EX',
'sb=extend' => 'SB/EX',
'sb=fo' => 'SB/FO',
'sb=format' => 'SB/FO',
'sb=le' => 'SB/LE',
'sb=lf' => '#/64',
'sb=lo' => 'SB/LO',
'sb=lower' => 'SB/LO',
'sb=nu' => 'SB/NU',
'sb=numeric' => 'SB/NU',
'sb=oletter' => 'SB/LE',
'sb=other' => 'SB/XX',
'sb=sc' => 'SB/SC',
'sb=scontinue' => 'SB/SC',
'sb=se' => '#/70',
'sb=sep' => '#/70',
'sb=sp' => 'SB/Sp',
'sb=st' => 'SB/ST',
'sb=sterm' => 'SB/ST',
'sb=up' => 'SB/UP',
'sb=upper' => 'SB/UP',
'sb=xx' => 'SB/XX',
'sc' => 'Gc/Sc',
'sc=aghb' => '#/511',
'sc=arab' => 'Sc/Arab',
'sc=arabic' => 'Sc/Arab',
'sc=armenian' => 'Sc/Armn',
'sc=armi' => '#/512',
'sc=armn' => 'Sc/Armn',
'sc=avestan' => '#/513',
'sc=avst' => '#/513',
'sc=bali' => '#/514',
'sc=balinese' => '#/514',
'sc=bamu' => '#/515',
'sc=bamum' => '#/515',
'sc=bass' => '#/516',
'sc=bassavah' => '#/516',
'sc=batak' => '#/517',
'sc=batk' => '#/517',
'sc=beng' => 'Sc/Beng',
'sc=bengali' => 'Sc/Beng',
'sc=bopo' => '#/518',
'sc=bopomofo' => '#/518',
'sc=brah' => '#/519',
'sc=brahmi' => '#/519',
'sc=brai' => '#/147',
'sc=braille' => '#/147',
'sc=bugi' => '#/520',
'sc=buginese' => '#/520',
'sc=buhd' => '#/521',
'sc=buhid' => '#/521',
'sc=cakm' => '#/522',
'sc=canadianaboriginal' => '#/523',
'sc=cans' => '#/523',
'sc=cari' => '#/524',
'sc=carian' => '#/524',
'sc=caucasianalbanian' => '#/511',
'sc=chakma' => '#/522',
'sc=cham' => 'Sc/Cham',
'sc=cher' => '#/525',
'sc=cherokee' => '#/525',
'sc=common' => 'Sc/Zyyy',
'sc=copt' => '#/526',
'sc=coptic' => '#/526',
'sc=cprt' => 'Sc/Cprt',
'sc=cuneiform' => '#/584',
'sc=cypriot' => 'Sc/Cprt',
'sc=cyrillic' => 'Sc/Cyrl',
'sc=cyrl' => 'Sc/Cyrl',
'sc=deseret' => '#/152',
'sc=deva' => 'Sc/Deva',
'sc=devanagari' => 'Sc/Deva',
'sc=dsrt' => '#/152',
'sc=dupl' => 'Sc/Dupl',
'sc=duployan' => 'Sc/Dupl',
'sc=egyp' => '#/527',
'sc=egyptianhieroglyphs' => '#/527',
'sc=elba' => '#/528',
'sc=elbasan' => '#/528',
'sc=ethi' => 'Sc/Ethi',
'sc=ethiopic' => 'Sc/Ethi',
'sc=geor' => 'Sc/Geor',
'sc=georgian' => 'Sc/Geor',
'sc=glag' => '#/529',
'sc=glagolitic' => '#/529',
'sc=goth' => '#/530',
'sc=gothic' => '#/530',
'sc=gran' => 'Sc/Gran',
'sc=grantha' => 'Sc/Gran',
'sc=greek' => 'Sc/Grek',
'sc=grek' => 'Sc/Grek',
'sc=gujarati' => 'Sc/Gujr',
'sc=gujr' => 'Sc/Gujr',
'sc=gurmukhi' => 'Sc/Guru',
'sc=guru' => 'Sc/Guru',
'sc=han' => 'Sc/Han',
'sc=hang' => 'Sc/Hang',
'sc=hangul' => 'Sc/Hang',
'sc=hani' => 'Sc/Han',
'sc=hano' => '#/531',
'sc=hanunoo' => '#/531',
'sc=hebr' => 'Sc/Hebr',
'sc=hebrew' => 'Sc/Hebr',
'sc=hira' => 'Sc/Hira',
'sc=hiragana' => 'Sc/Hira',
'sc=hmng' => 'Sc/Hmng',
'sc=imperialaramaic' => '#/512',
'sc=inherited' => 'Sc/Zinh',
'sc=inscriptionalpahlavi' => '#/557',
'sc=inscriptionalparthian' => '#/560',
'sc=ital' => '#/532',
'sc=java' => '#/533',
'sc=javanese' => '#/533',
'sc=kaithi' => '#/536',
'sc=kali' => '#/534',
'sc=kana' => 'Sc/Kana',
'sc=kannada' => 'Sc/Knda',
'sc=katakana' => 'Sc/Kana',
'sc=kayahli' => '#/534',
'sc=khar' => 'Sc/Khar',
'sc=kharoshthi' => 'Sc/Khar',
'sc=khmer' => 'Sc/Khmr',
'sc=khmr' => 'Sc/Khmr',
'sc=khoj' => '#/535',
'sc=khojki' => '#/535',
'sc=khudawadi' => '#/567',
'sc=knda' => 'Sc/Knda',
'sc=kthi' => '#/536',
'sc=lana' => 'Sc/Lana',
'sc=lao' => 'Sc/Lao',
'sc=laoo' => 'Sc/Lao',
'sc=latin' => 'Sc/Latn',
'sc=latn' => 'Sc/Latn',
'sc=lepc' => '#/537',
'sc=lepcha' => '#/537',
'sc=limb' => 'Sc/Limb',
'sc=limbu' => 'Sc/Limb',
'sc=lina' => '#/538',
'sc=linb' => 'Sc/Linb',
'sc=lineara' => '#/538',
'sc=linearb' => 'Sc/Linb',
'sc=lisu' => '#/99',
'sc=lyci' => '#/539',
'sc=lycian' => '#/539',
'sc=lydi' => '#/540',
'sc=lydian' => '#/540',
'sc=mahajani' => '#/541',
'sc=mahj' => '#/541',
'sc=malayalam' => 'Sc/Mlym',
'sc=mand' => '#/542',
'sc=mandaic' => '#/542',
'sc=mani' => '#/543',
'sc=manichaean' => '#/543',
'sc=meeteimayek' => '#/548',
'sc=mend' => '#/544',
'sc=mendekikakui' => '#/544',
'sc=merc' => '#/545',
'sc=mero' => '#/331',
'sc=meroiticcursive' => '#/545',
'sc=meroitichieroglyphs' => '#/331',
'sc=miao' => '#/546',
'sc=mlym' => 'Sc/Mlym',
'sc=modi' => '#/547',
'sc=mong' => 'Sc/Mong',
'sc=mongolian' => 'Sc/Mong',
'sc=mro' => '#/508',
'sc=mroo' => '#/508',
'sc=mtei' => '#/548',
'sc=myanmar' => '#/549',
'sc=mymr' => '#/549',
'sc=nabataean' => '#/550',
'sc=narb' => '#/306',
'sc=nbat' => '#/550',
'sc=newtailue' => 'Sc/Talu',
'sc=nko' => '#/509',
'sc=nkoo' => '#/509',
'sc=ogam' => '#/551',
'sc=ogham' => '#/551',
'sc=olchiki' => '#/163',
'sc=olck' => '#/163',
'sc=olditalic' => '#/532',
'sc=oldnortharabian' => '#/306',
'sc=oldpermic' => '#/555',
'sc=oldpersian' => '#/583',
'sc=oldsoutharabian' => '#/307',
'sc=oldturkic' => '#/552',
'sc=oriya' => 'Sc/Orya',
'sc=orkh' => '#/552',
'sc=orya' => 'Sc/Orya',
'sc=osma' => '#/553',
'sc=osmanya' => '#/553',
'sc=pahawhhmong' => 'Sc/Hmng',
'sc=palm' => '#/225',
'sc=palmyrene' => '#/225',
'sc=pauc' => '#/554',
'sc=paucinhau' => '#/554',
'sc=perm' => '#/555',
'sc=phag' => '#/556',
'sc=phagspa' => '#/556',
'sc=phli' => '#/557',
'sc=phlp' => '#/558',
'sc=phnx' => '#/559',
'sc=phoenician' => '#/559',
'sc=plrd' => '#/546',
'sc=prti' => '#/560',
'sc=psalterpahlavi' => '#/558',
'sc=qaac' => '#/526',
'sc=qaai' => 'Sc/Zinh',
'sc=rejang' => '#/561',
'sc=rjng' => '#/561',
'sc=runic' => '#/562',
'sc=runr' => '#/562',
'sc=samaritan' => '#/563',
'sc=samr' => '#/563',
'sc=sarb' => '#/307',
'sc=saur' => '#/564',
'sc=saurashtra' => '#/564',
'sc=sharada' => '#/565',
'sc=shavian' => '#/167',
'sc=shaw' => '#/167',
'sc=shrd' => '#/565',
'sc=sidd' => '#/566',
'sc=siddham' => '#/566',
'sc=sind' => '#/567',
'sc=sinh' => 'Sc/Sinh',
'sc=sinhala' => 'Sc/Sinh',
'sc=sora' => '#/568',
'sc=sorasompeng' => '#/568',
'sc=sund' => '#/569',
'sc=sundanese' => '#/569',
'sc=sylo' => '#/570',
'sc=sylotinagri' => '#/570',
'sc=syrc' => '#/571',
'sc=syriac' => '#/571',
'sc=tagalog' => '#/577',
'sc=tagb' => '#/572',
'sc=tagbanwa' => '#/572',
'sc=taile' => '#/574',
'sc=taitham' => 'Sc/Lana',
'sc=taiviet' => '#/575',
'sc=takr' => '#/573',
'sc=takri' => '#/573',
'sc=tale' => '#/574',
'sc=talu' => 'Sc/Talu',
'sc=tamil' => 'Sc/Taml',
'sc=taml' => 'Sc/Taml',
'sc=tavt' => '#/575',
'sc=telu' => 'Sc/Telu',
'sc=telugu' => 'Sc/Telu',
'sc=tfng' => '#/576',
'sc=tglg' => '#/577',
'sc=thaa' => '#/578',
'sc=thaana' => '#/578',
'sc=thai' => '#/579',
'sc=tibetan' => 'Sc/Tibt',
'sc=tibt' => 'Sc/Tibt',
'sc=tifinagh' => '#/576',
'sc=tirh' => '#/580',
'sc=tirhuta' => '#/580',
'sc=ugar' => '#/581',
'sc=ugaritic' => '#/581',
'sc=unknown' => 'Sc/Zzzz',
'sc=vai' => '#/510',
'sc=vaii' => '#/510',
'sc=wara' => '#/582',
'sc=warangciti' => '#/582',
'sc=xpeo' => '#/583',
'sc=xsux' => '#/584',
'sc=yi' => '#/507',
'sc=yiii' => '#/507',
'sc=zinh' => 'Sc/Zinh',
'sc=zyyy' => 'Sc/Zyyy',
'sc=zzzz' => 'Sc/Zzzz',
'scx=aghb' => '#/511',
'scx=arab' => 'Scx/Arab',
'scx=arabic' => 'Scx/Arab',
'scx=armenian' => 'Scx/Armn',
'scx=armi' => '#/512',
'scx=armn' => 'Scx/Armn',
'scx=avestan' => '#/513',
'scx=avst' => '#/513',
'scx=bali' => '#/514',
'scx=balinese' => '#/514',
'scx=bamu' => '#/515',
'scx=bamum' => '#/515',
'scx=bass' => '#/516',
'scx=bassavah' => '#/516',
'scx=batak' => '#/517',
'scx=batk' => '#/517',
'scx=beng' => 'Scx/Beng',
'scx=bengali' => 'Scx/Beng',
'scx=bopo' => 'Scx/Bopo',
'scx=bopomofo' => 'Scx/Bopo',
'scx=brah' => '#/519',
'scx=brahmi' => '#/519',
'scx=brai' => '#/147',
'scx=braille' => '#/147',
'scx=bugi' => '#/585',
'scx=buginese' => '#/585',
'scx=buhd' => '#/586',
'scx=buhid' => '#/586',
'scx=cakm' => 'Scx/Cakm',
'scx=canadianaboriginal' => '#/523',
'scx=cans' => '#/523',
'scx=cari' => '#/524',
'scx=carian' => '#/524',
'scx=caucasianalbanian' => '#/511',
'scx=chakma' => 'Scx/Cakm',
'scx=cham' => 'Sc/Cham',
'scx=cher' => '#/525',
'scx=cherokee' => '#/525',
'scx=common' => 'Scx/Zyyy',
'scx=copt' => 'Scx/Copt',
'scx=coptic' => 'Scx/Copt',
'scx=cprt' => 'Scx/Cprt',
'scx=cuneiform' => '#/584',
'scx=cypriot' => 'Scx/Cprt',
'scx=cyrillic' => 'Scx/Cyrl',
'scx=cyrl' => 'Scx/Cyrl',
'scx=deseret' => '#/152',
'scx=deva' => 'Scx/Deva',
'scx=devanagari' => 'Scx/Deva',
'scx=dsrt' => '#/152',
'scx=dupl' => 'Scx/Dupl',
'scx=duployan' => 'Scx/Dupl',
'scx=egyp' => '#/527',
'scx=egyptianhieroglyphs' => '#/527',
'scx=elba' => '#/528',
'scx=elbasan' => '#/528',
'scx=ethi' => 'Sc/Ethi',
'scx=ethiopic' => 'Sc/Ethi',
'scx=geor' => 'Scx/Geor',
'scx=georgian' => 'Scx/Geor',
'scx=glag' => '#/529',
'scx=glagolitic' => '#/529',
'scx=goth' => '#/530',
'scx=gothic' => '#/530',
'scx=gran' => 'Scx/Gran',
'scx=grantha' => 'Scx/Gran',
'scx=greek' => 'Scx/Grek',
'scx=grek' => 'Scx/Grek',
'scx=gujarati' => 'Scx/Gujr',
'scx=gujr' => 'Scx/Gujr',
'scx=gurmukhi' => 'Scx/Guru',
'scx=guru' => 'Scx/Guru',
'scx=han' => 'Scx/Han',
'scx=hang' => 'Scx/Hang',
'scx=hangul' => 'Scx/Hang',
'scx=hani' => 'Scx/Han',
'scx=hano' => '#/587',
'scx=hanunoo' => '#/587',
'scx=hebr' => 'Sc/Hebr',
'scx=hebrew' => 'Sc/Hebr',
'scx=hira' => 'Scx/Hira',
'scx=hiragana' => 'Scx/Hira',
'scx=hmng' => 'Sc/Hmng',
'scx=imperialaramaic' => '#/512',
'scx=inherited' => 'Scx/Zinh',
'scx=inscriptionalpahlavi' => '#/557',
'scx=inscriptionalparthian' => '#/560',
'scx=ital' => '#/532',
'scx=java' => '#/588',
'scx=javanese' => '#/588',
'scx=kaithi' => '#/590',
'scx=kali' => '#/158',
'scx=kana' => 'Scx/Kana',
'scx=kannada' => 'Scx/Knda',
'scx=katakana' => 'Scx/Kana',
'scx=kayahli' => '#/158',
'scx=khar' => 'Sc/Khar',
'scx=kharoshthi' => 'Sc/Khar',
'scx=khmer' => 'Sc/Khmr',
'scx=khmr' => 'Sc/Khmr',
'scx=khoj' => '#/589',
'scx=khojki' => '#/589',
'scx=khudawadi' => 'Scx/Sind',
'scx=knda' => 'Scx/Knda',
'scx=kthi' => '#/590',
'scx=lana' => 'Sc/Lana',
'scx=lao' => 'Sc/Lao',
'scx=laoo' => 'Sc/Lao',
'scx=latin' => 'Scx/Latn',
'scx=latn' => 'Scx/Latn',
'scx=lepc' => '#/537',
'scx=lepcha' => '#/537',
'scx=limb' => 'Scx/Limb',
'scx=limbu' => 'Scx/Limb',
'scx=lina' => '#/538',
'scx=linb' => 'Scx/Linb',
'scx=lineara' => '#/538',
'scx=linearb' => 'Scx/Linb',
'scx=lisu' => '#/99',
'scx=lyci' => '#/539',
'scx=lycian' => '#/539',
'scx=lydi' => '#/540',
'scx=lydian' => '#/540',
'scx=mahajani' => '#/591',
'scx=mahj' => '#/591',
'scx=malayalam' => 'Scx/Mlym',
'scx=mand' => '#/592',
'scx=mandaic' => '#/592',
'scx=mani' => '#/593',
'scx=manichaean' => '#/593',
'scx=meeteimayek' => '#/548',
'scx=mend' => '#/544',
'scx=mendekikakui' => '#/544',
'scx=merc' => '#/545',
'scx=mero' => '#/331',
'scx=meroiticcursive' => '#/545',
'scx=meroitichieroglyphs' => '#/331',
'scx=miao' => '#/546',
'scx=mlym' => 'Scx/Mlym',
'scx=modi' => '#/594',
'scx=mong' => 'Scx/Mong',
'scx=mongolian' => 'Scx/Mong',
'scx=mro' => '#/508',
'scx=mroo' => '#/508',
'scx=mtei' => '#/548',
'scx=myanmar' => 'Scx/Mymr',
'scx=mymr' => 'Scx/Mymr',
'scx=nabataean' => '#/550',
'scx=narb' => '#/306',
'scx=nbat' => '#/550',
'scx=newtailue' => 'Sc/Talu',
'scx=nko' => '#/509',
'scx=nkoo' => '#/509',
'scx=ogam' => '#/551',
'scx=ogham' => '#/551',
'scx=olchiki' => '#/163',
'scx=olck' => '#/163',
'scx=olditalic' => '#/532',
'scx=oldnortharabian' => '#/306',
'scx=oldpermic' => '#/555',
'scx=oldpersian' => '#/583',
'scx=oldsoutharabian' => '#/307',
'scx=oldturkic' => '#/552',
'scx=oriya' => 'Scx/Orya',
'scx=orkh' => '#/552',
'scx=orya' => 'Scx/Orya',
'scx=osma' => '#/553',
'scx=osmanya' => '#/553',
'scx=pahawhhmong' => 'Sc/Hmng',
'scx=palm' => '#/225',
'scx=palmyrene' => '#/225',
'scx=pauc' => '#/554',
'scx=paucinhau' => '#/554',
'scx=perm' => '#/555',
'scx=phag' => '#/595',
'scx=phagspa' => '#/595',
'scx=phli' => '#/557',
'scx=phlp' => 'Scx/Phlp',
'scx=phnx' => '#/559',
'scx=phoenician' => '#/559',
'scx=plrd' => '#/546',
'scx=prti' => '#/560',
'scx=psalterpahlavi' => 'Scx/Phlp',
'scx=qaac' => 'Scx/Copt',
'scx=qaai' => 'Scx/Zinh',
'scx=rejang' => '#/561',
'scx=rjng' => '#/561',
'scx=runic' => '#/562',
'scx=runr' => '#/562',
'scx=samaritan' => '#/563',
'scx=samr' => '#/563',
'scx=sarb' => '#/307',
'scx=saur' => '#/564',
'scx=saurashtra' => '#/564',
'scx=sharada' => '#/565',
'scx=shavian' => '#/167',
'scx=shaw' => '#/167',
'scx=shrd' => '#/565',
'scx=sidd' => '#/566',
'scx=siddham' => '#/566',
'scx=sind' => 'Scx/Sind',
'scx=sinh' => 'Scx/Sinh',
'scx=sinhala' => 'Scx/Sinh',
'scx=sora' => '#/568',
'scx=sorasompeng' => '#/568',
'scx=sund' => '#/569',
'scx=sundanese' => '#/569',
'scx=sylo' => '#/596',
'scx=sylotinagri' => '#/596',
'scx=syrc' => 'Scx/Syrc',
'scx=syriac' => 'Scx/Syrc',
'scx=tagalog' => '#/598',
'scx=tagb' => 'Scx/Tagb',
'scx=tagbanwa' => 'Scx/Tagb',
'scx=taile' => '#/597',
'scx=taitham' => 'Sc/Lana',
'scx=taiviet' => '#/575',
'scx=takr' => 'Scx/Takr',
'scx=takri' => 'Scx/Takr',
'scx=tale' => '#/597',
'scx=talu' => 'Sc/Talu',
'scx=tamil' => 'Scx/Taml',
'scx=taml' => 'Scx/Taml',
'scx=tavt' => '#/575',
'scx=telu' => 'Scx/Telu',
'scx=telugu' => 'Scx/Telu',
'scx=tfng' => '#/576',
'scx=tglg' => '#/598',
'scx=thaa' => 'Scx/Thaa',
'scx=thaana' => 'Scx/Thaa',
'scx=thai' => '#/579',
'scx=tibetan' => 'Sc/Tibt',
'scx=tibt' => 'Sc/Tibt',
'scx=tifinagh' => '#/576',
'scx=tirh' => 'Scx/Tirh',
'scx=tirhuta' => 'Scx/Tirh',
'scx=ugar' => '#/581',
'scx=ugaritic' => '#/581',
'scx=unknown' => 'Sc/Zzzz',
'scx=vai' => '#/510',
'scx=vaii' => '#/510',
'scx=wara' => '#/582',
'scx=warangciti' => '#/582',
'scx=xpeo' => '#/583',
'scx=xsux' => '#/584',
'scx=yi' => 'Scx/Yi',
'scx=yiii' => 'Scx/Yi',
'scx=zinh' => 'Scx/Zinh',
'scx=zyyy' => 'Scx/Zyyy',
'scx=zzzz' => 'Sc/Zzzz',
'sd' => 'SD/Y',
'sd=f' => '!SD/Y',
'sd=false' => '!SD/Y',
'sd=n' => '!SD/Y',
'sd=no' => '!SD/Y',
'sd=t' => 'SD/Y',
'sd=true' => 'SD/Y',
'sd=y' => 'SD/Y',
'sd=yes' => 'SD/Y',
'separator' => 'Gc/Z',
'sharada' => '#/565',
'shavian' => '#/167',
'shaw' => '#/167',
'shorthandformatcontrols' => '#/339',
'shrd' => '#/565',
'sidd' => '#/566',
'siddham' => '#/566',
'sind' => '#/567',
'sinh' => 'Sc/Sinh',
'sinhala' => 'Sc/Sinh',
'sinhalaarchaicnumbers' => '#/335',
'sk' => 'Gc/Sk',
'sm' => 'Gc/Sm',
'smallforms' => '#/244',
'smallformvariants' => '#/244',
'so' => 'Gc/So',
'softdotted' => 'SD/Y',
'sora' => '#/568',
'sorasompeng' => '#/568',
'space' => 'Perl/SpacePer',
'spaceperl' => 'Perl/SpacePer',
'spaceseparator' => 'Gc/Zs',
'spacingmark' => 'Gc/Mc',
'spacingmodifierletters' => '#/305',
'specials' => '#/200',
'sterm' => 'STerm/Y',
'sterm=f' => '!STerm/Y',
'sterm=false' => '!STerm/Y',
'sterm=n' => '!STerm/Y',
'sterm=no' => '!STerm/Y',
'sterm=t' => 'STerm/Y',
'sterm=true' => 'STerm/Y',
'sterm=y' => 'STerm/Y',
'sterm=yes' => 'STerm/Y',
'sund' => '#/569',
'sundanese' => '#/569',
'sundanesesup' => '#/280',
'sundanesesupplement' => '#/280',
'suparrowsa' => '#/245',
'suparrowsb' => '#/246',
'suparrowsc' => '#/247',
'superandsub' => '#/267',
'superscriptsandsubscripts' => '#/267',
'supmathoperators' => '#/319',
'supplementalarrowsa' => '#/245',
'supplementalarrowsb' => '#/246',
'supplementalarrowsc' => '#/247',
'supplementalmathematicaloperators' => '#/319',
'supplementalpunctuation' => '#/296',
'supplementaryprivateuseareaa' => '#/170',
'supplementaryprivateuseareab' => '#/171',
'suppuaa' => '#/170',
'suppuab' => '#/171',
'suppunctuation' => '#/296',
'surrogate' => '#/345',
'sylo' => '#/570',
'sylotinagri' => '#/570',
'symbol' => 'Gc/S',
'syrc' => '#/571',
'syriac' => '#/571',
'tagalog' => '#/577',
'tagb' => '#/572',
'tagbanwa' => '#/572',
'tags' => '#/103',
'taile' => '#/574',
'taitham' => 'Sc/Lana',
'taiviet' => '#/575',
'taixuanjing' => '#/269',
'taixuanjingsymbols' => '#/269',
'takr' => '#/573',
'takri' => '#/573',
'tale' => '#/574',
'talu' => 'Sc/Talu',
'tamil' => 'Sc/Taml',
'taml' => 'Sc/Taml',
'tavt' => '#/575',
'telu' => 'Sc/Telu',
'telugu' => 'Sc/Telu',
'term' => 'Term/Y',
'term=f' => '!Term/Y',
'term=false' => '!Term/Y',
'term=n' => '!Term/Y',
'term=no' => '!Term/Y',
'term=t' => 'Term/Y',
'term=true' => 'Term/Y',
'term=y' => 'Term/Y',
'term=yes' => 'Term/Y',
'terminalpunctuation' => 'Term/Y',
'tfng' => '#/576',
'tglg' => '#/577',
'thaa' => '#/578',
'thaana' => '#/578',
'thai' => '#/579',
'tibetan' => 'Sc/Tibt',
'tibt' => 'Sc/Tibt',
'tifinagh' => '#/576',
'tirh' => '#/580',
'tirhuta' => '#/580',
'title' => 'Perl/Title',
'titlecase' => 'Perl/Title',
'titlecaseletter' => 'Perl/Title',
'transportandmap' => '#/308',
'transportandmapsymbols' => '#/308',
'ucas' => '#/105',
'ucasext' => '#/177',
'ugar' => '#/581',
'ugaritic' => '#/581',
'uideo' => 'UIdeo/Y',
'uideo=f' => '!UIdeo/Y',
'uideo=false' => '!UIdeo/Y',
'uideo=n' => '!UIdeo/Y',
'uideo=no' => '!UIdeo/Y',
'uideo=t' => 'UIdeo/Y',
'uideo=true' => 'UIdeo/Y',
'uideo=y' => 'UIdeo/Y',
'uideo=yes' => 'UIdeo/Y',
'unassigned' => 'Gc/Cn',
'unicode' => '#/2',
'unifiedcanadianaboriginalsyllabics' => '#/105',
'unifiedcanadianaboriginalsyllabicsextended' => '#/177',
'unifiedideograph' => 'UIdeo/Y',
'unknown' => 'Sc/Zzzz',
'upper' => 'Upper/Y',
'upper=f' => '!Upper/Y',
'upper=false' => '!Upper/Y',
'upper=n' => '!Upper/Y',
'upper=no' => '!Upper/Y',
'upper=t' => 'Upper/Y',
'upper=true' => 'Upper/Y',
'upper=y' => 'Upper/Y',
'upper=yes' => 'Upper/Y',
'uppercase' => 'Upper/Y',
'uppercaseletter' => 'Gc/Lu',
'vai' => '#/510',
'vaii' => '#/510',
'variationselector' => '#/71',
'variationselectors' => '#/88',
'variationselectorssupplement' => '#/120',
'vedicext' => '#/204',
'vedicextensions' => '#/204',
'verticalforms' => '#/287',
'vertspace' => '#/4',
'vs' => '#/71',
'vs=f' => '#/!71',
'vs=false' => '#/!71',
'vs=n' => '#/!71',
'vs=no' => '#/!71',
'vs=t' => '#/71',
'vs=true' => '#/71',
'vs=y' => '#/71',
'vs=yes' => '#/71',
'vssup' => '#/120',
'wara' => '#/582',
'warangciti' => '#/582',
'wb=aletter' => 'WB/LE',
'wb=cr' => '#/63',
'wb=doublequote' => '#/72',
'wb=dq' => '#/72',
'wb=ex' => 'WB/EX',
'wb=extend' => 'SB/EX',
'wb=extendnumlet' => 'WB/EX',
'wb=fo' => 'WB/FO',
'wb=format' => 'WB/FO',
'wb=hebrewletter' => 'WB/HL',
'wb=hl' => 'WB/HL',
'wb=ka' => 'WB/KA',
'wb=katakana' => 'WB/KA',
'wb=le' => 'WB/LE',
'wb=lf' => '#/64',
'wb=mb' => 'WB/MB',
'wb=midletter' => 'WB/ML',
'wb=midnum' => 'WB/MN',
'wb=midnumlet' => 'WB/MB',
'wb=ml' => 'WB/ML',
'wb=mn' => 'WB/MN',
'wb=newline' => '#/73',
'wb=nl' => '#/73',
'wb=nu' => 'WB/NU',
'wb=numeric' => 'WB/NU',
'wb=other' => 'WB/XX',
'wb=regionalindicator' => '#/65',
'wb=ri' => '#/65',
'wb=singlequote' => '#/74',
'wb=sq' => '#/74',
'wb=xx' => 'WB/XX',
'whitespace' => 'Perl/SpacePer',
'word' => 'Perl/Word',
'wspace' => 'Perl/SpacePer',
'wspace=f' => '!Perl/SpacePer',
'wspace=false' => '!Perl/SpacePer',
'wspace=n' => '!Perl/SpacePer',
'wspace=no' => '!Perl/SpacePer',
'wspace=t' => 'Perl/SpacePer',
'wspace=true' => 'Perl/SpacePer',
'wspace=y' => 'Perl/SpacePer',
'wspace=yes' => 'Perl/SpacePer',
'xdigit' => 'Hex/Y',
'xidc' => 'XIDC/Y',
'xidc=f' => '!XIDC/Y',
'xidc=false' => '!XIDC/Y',
'xidc=n' => '!XIDC/Y',
'xidc=no' => '!XIDC/Y',
'xidc=t' => 'XIDC/Y',
'xidc=true' => 'XIDC/Y',
'xidc=y' => 'XIDC/Y',
'xidc=yes' => 'XIDC/Y',
'xidcontinue' => 'XIDC/Y',
'xids' => 'XIDS/Y',
'xids=f' => '!XIDS/Y',
'xids=false' => '!XIDS/Y',
'xids=n' => '!XIDS/Y',
'xids=no' => '!XIDS/Y',
'xids=t' => 'XIDS/Y',
'xids=true' => 'XIDS/Y',
'xids=y' => 'XIDS/Y',
'xids=yes' => 'XIDS/Y',
'xidstart' => 'XIDS/Y',
'xpeo' => '#/583',
'xperlspace' => 'Perl/SpacePer',
'xposixalnum' => 'Perl/Alnum',
'xposixalpha' => 'Alpha/Y',
'xposixblank' => 'Perl/Blank',
'xposixcntrl' => '#/343',
'xposixdigit' => 'Gc/Nd',
'xposixgraph' => 'Perl/Graph',
'xposixlower' => 'Lower/Y',
'xposixprint' => 'Perl/Print',
'xposixpunct' => 'Perl/XPosixPu',
'xposixspace' => 'Perl/SpacePer',
'xposixupper' => 'Upper/Y',
'xposixword' => 'Perl/Word',
'xposixxdigit' => 'Hex/Y',
'xsux' => '#/584',
'yi' => '#/507',
'yiii' => '#/507',
'yijing' => '#/144',
'yijinghexagramsymbols' => '#/144',
'yiradicals' => '#/249',
'yisyllables' => '#/270',
'z' => 'Gc/Z',
'zinh' => 'Sc/Zinh',
'zl' => '#/346',
'zp' => '#/347',
'zs' => 'Gc/Zs',
'zyyy' => 'Sc/Zyyy',
'zzzz' => 'Sc/Zzzz',
);

%utf8::nv_floating_to_rational = (
'-0.5' => '-1/2',
'0.0625' => '1/16',
'0.1' => '1/10',
'0.111111111111111' => '1/9',
'0.125' => '1/8',
'0.142857142857143' => '1/7',
'0.166666666666667' => '1/6',
'0.1875' => '3/16',
'0.2' => '1/5',
'0.25' => '1/4',
'0.333333333333333' => '1/3',
'0.375' => '3/8',
'0.4' => '2/5',
'0.5' => '1/2',
'0.6' => '3/5',
'0.625' => '5/8',
'0.666666666666667' => '2/3',
'0.75' => '3/4',
'0.8' => '4/5',
'0.833333333333333' => '5/6',
'0.875' => '7/8',
'1.5' => '3/2',
'2.5' => '5/2',
'3.5' => '7/2',
'4.5' => '9/2',
'5.5' => '11/2',
'6.5' => '13/2',
'7.5' => '15/2',
'8.5' => '17/2',
);

$utf8::max_floating_slop = 0.001;

%utf8::why_deprecated = (
'#/426' => 'Deprecated by Unicode because surrogates should never appear in well-formed text, and therefore shouldn\'t be the basis for line breaking',
'Hyphen/Y' => 'Supplanted by Line_Break property values; see www.unicode.org/reports/tr14',
);

%utf8::caseless_equivalent = (
'gc=ll' => 'Gc/LC',
'gc=lowercaseletter' => 'Gc/LC',
'gc=lt' => 'Gc/LC',
'gc=lu' => 'Gc/LC',
'gc=titlecaseletter' => 'Gc/LC',
'gc=uppercaseletter' => 'Gc/LC',
'isll' => 'Gc/LC',
'islower' => 'Cased/Y',
'islowercase' => 'Cased/Y',
'islowercaseletter' => 'Gc/LC',
'islt' => 'Gc/LC',
'islu' => 'Gc/LC',
'isposixlower' => '#/6',
'isposixupper' => '#/6',
'istitle' => 'Cased/Y',
'istitlecase' => 'Cased/Y',
'istitlecaseletter' => 'Gc/LC',
'isupper' => 'Cased/Y',
'isuppercase' => 'Cased/Y',
'isuppercaseletter' => 'Gc/LC',
'isxposixlower' => 'Cased/Y',
'isxposixupper' => 'Cased/Y',
'll' => 'Gc/LC',
'lower' => 'Cased/Y',
'lower=f' => '!Cased/Y',
'lower=false' => '!Cased/Y',
'lower=n' => '!Cased/Y',
'lower=no' => '!Cased/Y',
'lower=t' => 'Cased/Y',
'lower=true' => 'Cased/Y',
'lower=y' => 'Cased/Y',
'lower=yes' => 'Cased/Y',
'lowercase' => 'Cased/Y',
'lowercaseletter' => 'Gc/LC',
'lt' => 'Gc/LC',
'lu' => 'Gc/LC',
'posixlower' => '#/6',
'posixupper' => '#/6',
'title' => 'Cased/Y',
'titlecase' => 'Cased/Y',
'titlecaseletter' => 'Gc/LC',
'upper' => 'Cased/Y',
'upper=f' => '!Cased/Y',
'upper=false' => '!Cased/Y',
'upper=n' => '!Cased/Y',
'upper=no' => '!Cased/Y',
'upper=t' => 'Cased/Y',
'upper=true' => 'Cased/Y',
'upper=y' => 'Cased/Y',
'upper=yes' => 'Cased/Y',
'uppercase' => 'Cased/Y',
'uppercaseletter' => 'Gc/LC',
'xposixlower' => 'Cased/Y',
'xposixupper' => 'Cased/Y',
);

%utf8::loose_property_to_file_of = (
'age' => 'To/Age',
'bc' => 'To/Bc',
'bidiclass' => 'To/Bc',
'bidimirroringglyph' => 'To/Bmg',
'bidipairedbracket' => 'To/Bpb',
'bidipairedbrackettype' => 'To/Bpt',
'bmg' => 'To/Bmg',
'bpb' => 'To/Bpb',
'bpt' => 'To/Bpt',
'canonicalcombiningclass' => 'CombiningClass',
'casefolding' => 'To/Cf',
'category' => 'To/Gc',
'ccc' => 'CombiningClass',
'cf' => 'To/Cf',
'ea' => 'To/Ea',
'eastasianwidth' => 'To/Ea',
'gc' => 'To/Gc',
'gcb' => 'To/GCB',
'generalcategory' => 'To/Gc',
'graphemeclusterbreak' => 'To/GCB',
'hangulsyllabletype' => 'To/Hst',
'hst' => 'To/Hst',
'isc' => 'To/Isc',
'isocomment' => 'To/Isc',
'jg' => 'To/Jg',
'joininggroup' => 'To/Jg',
'joiningtype' => 'To/Jt',
'jt' => 'To/Jt',
'lb' => 'To/Lb',
'lc' => 'To/Lc',
'linebreak' => 'To/Lb',
'lowercasemapping' => 'To/Lc',
'na1' => 'To/Na1',
'namealias' => 'To/NameAlia',
'nfcqc' => 'To/NFCQC',
'nfcquickcheck' => 'To/NFCQC',
'nfdqc' => 'To/NFDQC',
'nfdquickcheck' => 'To/NFDQC',
'nfkccasefold' => 'To/NFKCCF',
'nfkccf' => 'To/NFKCCF',
'nfkcqc' => 'To/NFKCQC',
'nfkcquickcheck' => 'To/NFKCQC',
'nfkdqc' => 'To/NFKDQC',
'nfkdquickcheck' => 'To/NFKDQC',
'nt' => 'To/Nt',
'numerictype' => 'To/Nt',
'numericvalue' => 'To/Nv',
'nv' => 'To/Nv',
'perldecimaldigit' => 'To/PerlDeci',
'sb' => 'To/SB',
'sc' => 'To/Sc',
'script' => 'To/Sc',
'scriptextensions' => 'To/Scx',
'scx' => 'To/Scx',
'sentencebreak' => 'To/SB',
'tc' => 'To/Tc',
'titlecasemapping' => 'To/Tc',
'uc' => 'To/Uc',
'unicode1name' => 'To/Na1',
'uppercasemapping' => 'To/Uc',
'wb' => 'To/WB',
'wordbreak' => 'To/WB',
);

%utf8::file_to_swash_name = (
'CombiningClass' => 'ToCombiningClass',
'To/Age' => 'ToAge',
'To/Bc' => 'ToBc',
'To/Bmg' => 'ToBmg',
'To/Bpb' => 'ToBpb',
'To/Bpt' => 'ToBpt',
'To/Cf' => 'ToCf',
'To/Ea' => 'ToEa',
'To/Gc' => 'ToGc',
'To/GCB' => 'ToGCB',
'To/Hst' => 'ToHst',
'To/Isc' => 'ToIsc',
'To/Jg' => 'ToJg',
'To/Jt' => 'ToJt',
'To/Lb' => 'ToLb',
'To/Lc' => 'ToLc',
'To/Na1' => 'ToNa1',
'To/NameAlia' => 'ToNameAlias',
'To/NFCQC' => 'ToNFCQC',
'To/NFDQC' => 'ToNFDQC',
'To/NFKCCF' => 'ToNFKCCF',
'To/NFKCQC' => 'ToNFKCQC',
'To/NFKDQC' => 'ToNFKDQC',
'To/Nt' => 'ToNt',
'To/Nv' => 'ToNv',
'To/PerlDeci' => 'ToPerlDecimalDigit',
'To/SB' => 'ToSB',
'To/Sc' => 'ToSc',
'To/Scx' => 'ToScx',
'To/Tc' => 'ToTc',
'To/Uc' => 'ToUc',
'To/WB' => 'ToWB',
);

1;
