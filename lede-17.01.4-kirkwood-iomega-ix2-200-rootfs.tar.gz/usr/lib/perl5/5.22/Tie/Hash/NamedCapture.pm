use strict;
package Tie::Hash::NamedCapture;

our $VERSION = "0.09";

require XSLoader;
XSLoader::load(); # This returns true, which makes require happy.

__END__

