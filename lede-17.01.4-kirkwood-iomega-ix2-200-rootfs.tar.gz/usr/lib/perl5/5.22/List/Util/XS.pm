package List::Util::XS;
use strict;
use List::Util;

our $VERSION = "1.41";       # FIXUP
$VERSION = eval $VERSION;    # FIXUP

1;
__END__

